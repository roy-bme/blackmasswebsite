# Handoff: Indaba — Operations Portal (v1)

Target repo: `zimxfinance/Indaba` (and the `app/indaba/...` routes inside `roy-bme/blackmasswebsite`).
Stack: **Next.js 14 (App Router) + Tailwind + Supabase** — already established in `blackmasswebsite`.
Audience: Claude Code, taking this bundle as the build spec for a mobile-first rebuild of `indaba.zimx.io`.

---

## 0 — Read this first

The HTML/JSX files in this bundle are **design references**, not production code. They render React via in-browser Babel, use inline styles, and live in a flat folder. **Do not ship them**. Your job is to recreate the screens **pixel-faithfully** in the existing Next.js + Tailwind environment under `app/indaba/...`, reusing the brand tokens already defined in `tailwind.config.ts` and replacing the existing `(ops)` pages.

The brief lives at the top of the conversation; the canonical IA, role permissions, and module list are all in §2 / §4 / §5 of that brief. Treat this README as the design spec; treat the brief as the product spec.

**Fidelity:** **High-fidelity.** Final colors, type, spacing, layout, and interactions are all locked. Match exactly.

---

## 1 — How to consume this bundle

1. Open `Indaba Portal.html` in a browser to see every screen on a pan/zoom canvas, organized into 11 sections. Click any artboard's expand to fullscreen it.
2. Each module has its source under `screens/<module>.jsx`. Each component is plain React JSX that you can read for exact structure, copy, and layout.
3. `tokens.css` declares CSS variables. The same values are mirrored as Tailwind tokens — see §4 below.
4. `components.jsx` defines the shared atoms (Button, Pill, Card, Avatar, Phone, PhoneTabs, IndabaLogo, icons, sector dots).

**Out of scope** (per brief §7): ZITF, magic-link auth, public marketing, native mobile.

---

## 2 — IA & role gating (must be enforced server-side too)

Bottom tab bar (mobile) and left rail (desktop) per role:

| Role | Modules visible |
|---|---|
| **admin** (Roy) | Dashboard, Map, Directory, Graph, Intros, Events, Compliance, Agent, Feed |
| **ops** (Brendon) | Dashboard, Map, Directory, Feed |
| **bd** (Tafadzwa) | Dashboard, Intros, Events, Directory, Feed |
| **compliance** (Victor) | Dashboard, Compliance, Agent (brief + reg subset only), Feed |

Notification dots: Feed unread count, Compliance queue count, Intros pending count (admin only).

---

## 3 — Modules → file map

Every module has mobile + desktop. States (loading skeleton / error / empty / offline) are catalogued in `screens/modules.jsx → StatesCatalog` and demonstrated inline in each module.

| Module | File | Notes |
|---|---|---|
| Auth (login + error) | `screens/auth.jsx` | Email + password. Right-side ambient Bulawayo map on desktop. First-login forced password change reuses the same `Field` component with hint copy. |
| Dashboards (4 roles) | `screens/dashboards.jsx` | Each role gets its own first view. Roy = exec funnel + Launch-6 + agent strip + needs-decision. Victor = queue + agent brief. Brendon = Today + map preview. Tafadzwa = This week. |
| Map | `screens/map.jsx` | `MapMobile`, `MapMobilePinDrop`, `MapDesktop`. Use Leaflet (already in repo). Sector circle markers, gold-diamond intro markers, dashed polylines for supply links, dashed polygons for zones. Pin-drop = floating + → crosshair → bottom sheet (2-tap target). |
| Directory | `screens/directory.jsx` | 8 lanes inc. agent-driven **Suggested** (gold-tinted, leftmost). Promote action turns a `discovery_candidate` row into a `business` row. Mobile = swipeable single-lane view. |
| Graph | `screens/graph.jsx` | Hand-rolled SVG, four sector layers as horizontal rails, gold edges + gold-ringed nodes for loop members. "Detect loops" button calls existing RPC. Mobile = list view grouped by supplier (touch-only, no pan/zoom). |
| Intros | `screens/modules.jsx → IntrosMobile/Desktop` | Cards + side detail panel. Approve (Roy) is admin-only and persists `roy_approved=true`. |
| Events | `screens/modules.jsx → EventsMobile` | Upcoming/Past tabs. Priority left stripe, urgency pill from days-to-event. Debrief = full-screen on mobile, dialog on desktop. |
| Feed | `screens/modules.jsx → FeedMobile` | Channel pill on every post. Channel-scoped per role: ops → ground_ops, bd → bd_networking, compliance → compliance, admin → all + admin-only channel. Sticky bottom composer on mobile, top on desktop. |
| Compliance Queue | `screens/modules.jsx → ComplianceMobile` | Severity left-border (info/warning/blocker). Open → in_review → resolved/escalated. New tables: `compliance_flags`, `regulatory_signals`. |
| Agent Console | `screens/modules.jsx → AgentConsoleDesktop` | Brief (markdown rendered) + Suggested actions + Recent runs (mono terminal log, reads `agent_runs`) + Discovery feed. Compliance gets a read-only subset (brief + regulatory signals only). |
| Settings | `screens/modules.jsx → SettingsMobile` | Profile + sign out. That's it. |

---

## 4 — Design tokens

Already partially in `tailwind.config.ts` (`zimx.gold`, `zimx.green`, `sector.*`). **Add** the ink scale and line tokens:

```ts
// tailwind.config.ts — extend colors
ink: { 900: "#14161a", 800: "#1a1d22", 700: "#1f2228", 600: "#262a31", 500: "#2f343c", 400: "#3a3f48", 300: "#4a4f59" },
line: { 10: "rgba(255,255,255,0.08)", 15: "rgba(255,255,255,0.12)", 20: "rgba(255,255,255,0.18)", 30: "rgba(255,255,255,0.28)" },
fg:   { DEFAULT: "#ffffff", mute: "rgba(255,255,255,0.62)", dim: "rgba(255,255,255,0.42)", faint: "rgba(255,255,255,0.24)" },
status: { ok: "#4ec38a", warn: "#e6a83c", bad: "#e2614b", info: "#5aa8e6" },
```

**Sector colors** (use existing `sector.*` from `tailwind.config.ts`):
mining `#BA7517` · manufacturing `#E24B4A` · retail/wholesale `#378ADD` · services `#7F77DD` · agriculture/fmcg `#1D9E75` · fuel `#D4537E`.

**Gold:** `#D4AF37` — primary actions, pending state, eyebrow accents, agent-discovered surfaces. Used sparingly.

**Type:** Inter (300/400/500/600) for sans · JetBrains Mono (400/500) for **all** labels, eyebrows, metrics, IDs, timestamps, button text, pill text. Display: 48–72px desktop / 32–40px mobile, weight 300, tracking `-0.025em`. Body: 13–14px / 400. Eyebrow: 11px mono / 0.14em / uppercase / `fg.dim`.

**Radius:** `0` everywhere (already configured: `borderRadius.none = "0px"`). 2px allowed only on overlays.

**Spacing:** 4 · 8 · 12 · 16 · 24 · 32 · 48.

**Borders:** hairlines only — `line/10`, `line/15`, `line/20`. No drop shadows on chrome; map markers and floating + use a 2px ink-900 ring instead.

**Voice:** terse, operational, lowercase where rhythm allows. No emoji. No marketing tone. Empty states are short and useful.

---

## 5 — Components to build (Tailwind + RSC where possible)

Reuse names from `components.jsx`:

- `<Button variant="primary|solid|ghost|bare|danger" size="sm|md|lg">` — mono uppercase, 0.14em tracking, no radius.
- `<Pill tone="neutral|gold|ok|warn|bad|info|solid" strong?>` — mono 10px, hairline border, padded 3×8.
- `<SectorChip sector active>` and `<SectorDot sector size>` — sector colors driven by `tailwind.config.ts`.
- `<Card padding accent>` — bg `ink-800`, border `line-10`, optional 2px gold left accent for primary cards.
- `<Eyebrow gold?>` — 11px mono, 0.14em tracking, uppercase.
- `<Avatar name size gold?>` — square (no radius), initials, mono.
- `<IndabaLogo>` — three white horizontal bars + gold diagonal slash + ZIMX wordmark. Source SVG inline in `components.jsx → ZimXMark`. Above page titles use `INDABA` as a mono-spaced eyebrow.
- **Bottom sheet** — drag handle, hairline top border, `ink-800` bg, full-width grid action row.
- **Skeleton** — `keyframes shimmer` + 200% gradient (see `tokens.css`). Match final layout.
- **Empty state** — dashed `line-15` border, mono "EMPTY" eyebrow, 14px headline, 12px `fg.mute` body.
- **Error state** — `bad/30` border, `bad/06` bg, mono "ERROR · code" eyebrow, retry button.
- **Offline banner** — warn-tone, persistent at top of mobile view when offline; shows queued submissions count.
- **Toast** — `ink-600` bg, status icon, optional gold "UNDO" link aligned right.

**Icon set:** stick with **Lucide** (it's already in the dependency style). The inline `I.*` icons in `components.jsx` are stroke-1.6, 18×18 — that's the target spec.

---

## 6 — Interactions & behaviour

- **Pin-drop (Map):** floating + → map enters drop mode (crosshair cursor, dim overlay, top instruction card) → tap location → bottom sheet with auto-geocoded address (use existing `app/api/ops/reverse-geocode/route.ts`), sector picker, name field, save. **Two-tap target.**
- **Directory swipe lanes (mobile):** horizontal scroll of stage chips, current lane shown below. Swipe-back gesture on detail screens.
- **Promote suggestion → identified:** one tap on the Promote button in a Suggested card. POST creates a `business` row, marks the `discovery_candidate` dismissed, optimistically moves the card to Identified.
- **Approve intro (Roy):** admin-only button. Sets `roy_approved=true`, posts a system message into the `bd_networking` channel.
- **Convert post → task:** any feed post has a kebab menu with this action; opens a `ConvertToTaskDialog` prefilled with the post body.
- **Pull-to-refresh** on every mobile list view.
- **Offline:** map caches last-known business positions (IndexedDB or service worker). Form submits queue and retry on reconnect — design indicator is the orange offline banner with a "2 queued" count.
- **Animations:** keep them small and operational. 120ms ease-out on hover; 200ms ease-in-out on bottom-sheet slide; no decorative motion.

---

## 7 — State & data

The repo already has the shape for businesses, supply_chain_links, loops, introductions, events, tasks, users, zones. **Add new tables:**

```sql
-- Discovery (agent-fed Suggested lane)
discovery_candidates (id, name, sector, confidence, source, payload jsonb, status, created_at)
pipeline_signals (id, candidate_id, kind, evidence, created_at)

-- Compliance
compliance_flags (id, severity, source, business_id?, link_id?, summary, status, notes, created_at, resolved_at)
regulatory_signals (id, jurisdiction, source, headline, body, severity, exposure jsonb, created_at)

-- Agent
agent_runs (id, agent_name, status, started_at, ended_at, duration_ms, outputs jsonb, trace_url)
agent_briefs (id, run_id, markdown, created_at)
agent_suggestions (id, kind, target_id, payload jsonb, status, created_at, accepted_at, accepted_by)
```

Add a `feed_channels` enum (`admin`, `ground_ops`, `bd_networking`, `compliance`) and gate `feed_posts.channel` reads via RLS by role.

---

## 8 — Accessibility

- WCAG AA contrast minimum (the dark palette is already AA against `ink-700`; check `fg.mute` and `fg.dim` against any non-default background).
- Keyboard reachability on all controls. ARIA labels on icon-only buttons (the floating +, kebab menus, the gold mic prompt).
- `aria-live="polite"` on form-submit status and on the offline banner.
- Status-bar safe areas respected on mobile (use `env(safe-area-inset-*)`).

---

## 9 — Build order suggestion

1. Tokens + components atoms (`Button`, `Pill`, `Card`, `Avatar`, `Eyebrow`, `SectorDot/Chip`, `IndabaLogo`).
2. Mobile shell (bottom tabs + status-bar-safe header) + Desktop shell (left rail + header with breadcrumb + ⌘K stub).
3. Auth → Dashboard (one role at a time, start with Brendon — simplest, least dependencies).
4. Map → Directory (these two share the businesses model and the most surface area).
5. Intros → Events → Feed.
6. Compliance Queue (needs new tables).
7. Agent Console (needs new tables + brief markdown rendering).
8. Settings.
9. Pass over every screen for skeleton/error/empty states (the catalog in `screens/modules.jsx → StatesCatalog` is the spec).

---

## 10 — Files in this bundle

- `Indaba Portal.html` — open this. The full canvas.
- `tokens.css` — CSS-var source of truth.
- `components.jsx` — atoms.
- `design-canvas.jsx` — canvas runtime; ignore for build.
- `screens/design-system.jsx` — the design system reference card.
- `screens/auth.jsx`
- `screens/dashboards.jsx`
- `screens/map.jsx`
- `screens/directory.jsx`
- `screens/graph.jsx`
- `screens/modules.jsx` — Intros, Events, Feed, Compliance, Agent, Settings, States catalog.

Roy will sign off the canvas before this gets implemented. Any spec ambiguity → ask before you guess.
