/* Indaba shared components */
const { useState, useMemo, useEffect, useRef } = React;

/* ---------- Logo ---------- */
function ZimXMark({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      <rect x="3" y="5" width="18" height="2" fill="#fff" />
      <rect x="3" y="11" width="18" height="2" fill="#fff" />
      <rect x="3" y="17" width="18" height="2" fill="#fff" />
      <path d="M5 21 L19 3" stroke="#D4AF37" strokeWidth="2.2" strokeLinecap="square" />
    </svg>
  );
}
function Wordmark({ size = 13 }) {
  return (
    <span className="mono" style={{ fontSize: size, letterSpacing: '0.18em', fontWeight: 600 }}>
      ZIMX
    </span>
  );
}
function IndabaLogo({ size = 18 }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
      <ZimXMark size={size} />
      <Wordmark size={size - 4} />
    </span>
  );
}

/* ---------- Eyebrow ---------- */
function Eyebrow({ children, gold, style }) {
  return (
    <div className="eyebrow" style={{ color: gold ? 'var(--gold)' : undefined, ...style }}>
      {children}
    </div>
  );
}

/* ---------- Buttons ---------- */
function Button({ children, variant = 'ghost', size = 'md', icon, fullWidth, onClick, style, className }) {
  const sizes = {
    sm: { padding: '6px 10px', fontSize: 11 },
    md: { padding: '10px 16px', fontSize: 12 },
    lg: { padding: '14px 22px', fontSize: 13 },
  };
  const variants = {
    primary: { background: 'var(--gold)', color: '#1a1612', border: '1px solid var(--gold)' },
    solid: { background: '#fff', color: 'var(--ink-700)', border: '1px solid #fff' },
    ghost: { background: 'transparent', color: '#fff', border: '1px solid var(--line-20)' },
    bare: { background: 'transparent', color: 'var(--fg-mute)', border: '1px solid transparent' },
    danger: { background: 'transparent', color: 'var(--bad)', border: '1px solid rgba(226,97,75,0.35)' },
  };
  return (
    <button onClick={onClick}
      className={className}
      style={{
        fontFamily: 'var(--mono)', textTransform: 'uppercase', letterSpacing: '0.14em',
        cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        width: fullWidth ? '100%' : undefined, lineHeight: 1,
        ...sizes[size], ...variants[variant], ...style,
      }}>
      {icon}{children}
    </button>
  );
}

/* ---------- Pill / Chip ---------- */
function Pill({ children, tone = 'neutral', strong, mono = true, style }) {
  const tones = {
    neutral:  { bg: 'rgba(255,255,255,0.06)', fg: 'rgba(255,255,255,0.78)', bd: 'var(--line-15)' },
    gold:     { bg: 'rgba(212,175,55,0.10)', fg: 'var(--gold)', bd: 'rgba(212,175,55,0.35)' },
    ok:       { bg: 'rgba(78,195,138,0.10)', fg: 'var(--ok)', bd: 'rgba(78,195,138,0.30)' },
    warn:     { bg: 'rgba(230,168,60,0.10)', fg: 'var(--warn)', bd: 'rgba(230,168,60,0.30)' },
    bad:      { bg: 'rgba(226,97,75,0.10)', fg: 'var(--bad)', bd: 'rgba(226,97,75,0.30)' },
    info:     { bg: 'rgba(90,168,230,0.10)', fg: 'var(--info)', bd: 'rgba(90,168,230,0.30)' },
    solid:    { bg: '#fff', fg: 'var(--ink-700)', bd: '#fff' },
  };
  const t = tones[tone];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      background: strong ? t.fg : t.bg, color: strong ? '#1a1612' : t.fg,
      border: `1px solid ${t.bd}`, padding: '3px 8px',
      fontFamily: mono ? 'var(--mono)' : 'var(--sans)',
      fontSize: 10, letterSpacing: mono ? '0.12em' : 'normal', textTransform: mono ? 'uppercase' : 'none',
      lineHeight: 1.3, ...style,
    }}>{children}</span>
  );
}

function SectorDot({ sector, size = 8 }) {
  const map = {
    mining: 'var(--sec-mining)', manufacturing: 'var(--sec-manufacturing)',
    retail: 'var(--sec-retail)', services: 'var(--sec-services)',
    agriculture: 'var(--sec-agriculture)', fuel: 'var(--sec-fuel)',
    fmcg: 'var(--sec-fmcg)', wholesale: 'var(--sec-wholesale)',
  };
  return <span style={{ display: 'inline-block', width: size, height: size, background: map[sector] || '#888', borderRadius: 0 }} />;
}

function SectorChip({ sector, active }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '4px 8px', border: `1px solid ${active ? 'var(--line-30)' : 'var(--line-15)'}`,
      background: active ? 'rgba(255,255,255,0.06)' : 'transparent',
      fontFamily: 'var(--mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.12em',
      color: active ? '#fff' : 'var(--fg-mute)', cursor: 'pointer',
    }}>
      <SectorDot sector={sector} />{sector}
    </span>
  );
}

/* ---------- Card ---------- */
function Card({ children, padding = 16, style, accent }) {
  return (
    <div style={{
      background: 'var(--ink-800)',
      border: '1px solid var(--line-10)',
      borderLeft: accent ? `2px solid ${accent}` : undefined,
      padding,
      ...style,
    }}>{children}</div>
  );
}

/* ---------- Avatar ---------- */
function Avatar({ name, size = 28, gold }) {
  const initials = (name || '').split(' ').map(s => s[0]).slice(0, 2).join('').toUpperCase();
  return (
    <span style={{
      width: size, height: size, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      background: gold ? 'var(--gold)' : 'var(--ink-500)',
      color: gold ? '#1a1612' : '#fff',
      fontFamily: 'var(--mono)', fontSize: size * 0.36, fontWeight: 600, letterSpacing: '0.04em',
      border: '1px solid var(--line-15)',
    }}>{initials}</span>
  );
}

/* ---------- Phone Frame (375x812) ---------- */
function Phone({ children, label }) {
  return (
    <div style={{ width: 375, height: 812, position: 'relative', background: 'var(--ink-700)', border: '1px solid var(--line-15)', overflow: 'hidden' }}>
      {/* Status bar */}
      <div style={{ height: 44, padding: '0 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontFamily: 'var(--mono)', fontSize: 13, color: '#fff' }}>
        <span style={{ fontWeight: 600 }}>9:41</span>
        <span style={{ display: 'inline-flex', gap: 6, alignItems: 'center' }}>
          <svg width="16" height="10" viewBox="0 0 16 10"><rect x="0" y="6" width="2" height="4" fill="#fff" /><rect x="4" y="4" width="2" height="6" fill="#fff" /><rect x="8" y="2" width="2" height="8" fill="#fff" /><rect x="12" y="0" width="2" height="10" fill="#fff" /></svg>
          <svg width="22" height="10" viewBox="0 0 22 10"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#fff" strokeOpacity="0.5"/><rect x="2" y="2" width="14" height="6" fill="#fff" /></svg>
        </span>
      </div>
      <div style={{ height: 768, position: 'relative' }}>{children}</div>
    </div>
  );
}

/* ---------- Phone bottom tab bar ---------- */
function PhoneTabs({ tabs, active }) {
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      borderTop: '1px solid var(--line-10)', background: 'rgba(20,22,26,0.92)', backdropFilter: 'blur(10px)',
      display: 'grid', gridTemplateColumns: `repeat(${tabs.length}, 1fr)`,
      paddingBottom: 14, paddingTop: 10,
    }}>
      {tabs.map((t) => (
        <div key={t.label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, color: t.label === active ? '#fff' : 'var(--fg-dim)' }}>
          <span style={{ position: 'relative' }}>
            {t.icon}
            {t.badge ? (
              <span style={{ position: 'absolute', top: -4, right: -8, background: 'var(--gold)', color: '#1a1612', fontFamily: 'var(--mono)', fontSize: 9, padding: '1px 4px', fontWeight: 700 }}>{t.badge}</span>
            ) : null}
          </span>
          <span className="mono" style={{ fontSize: 9, letterSpacing: '0.12em', textTransform: 'uppercase' }}>{t.label}</span>
        </div>
      ))}
    </div>
  );
}

/* ---------- Tiny icon set (Lucide-style strokes) ---------- */
const I = {
  home:    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 11l9-8 9 8v9a2 2 0 01-2 2h-4v-7H9v7H5a2 2 0 01-2-2v-9z"/></svg>,
  map:     <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M9 4l-6 2v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14"/></svg>,
  list:    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg>,
  graph:   <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><path d="M7.5 7.5l3 9M16.5 7.5l-3 9M8 6h8"/></svg>,
  intros:  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 11h-6M19 8v6"/></svg>,
  events:  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="16" rx="0"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>,
  feed:    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 01-2 2H8l-5 4V5a2 2 0 012-2h14a2 2 0 012 2v10z"/></svg>,
  shield:  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
  agent:   <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="6" width="16" height="14" rx="0"/><path d="M9 2v4M15 2v4M9 13h.01M15 13h.01M9 17h6"/></svg>,
  plus:    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>,
  search:  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>,
  filter:  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z"/></svg>,
  chevron: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>,
  chevronD:<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M6 9l6 6 6-6"/></svg>,
  alert:   <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 9v4M12 17h.01"/><circle cx="12" cy="12" r="10"/></svg>,
  check:   <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>,
  mic:     <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v4"/></svg>,
  camera:  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/></svg>,
  dots:    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg>,
  refresh: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 11-3-6.7L21 8M21 3v5h-5"/></svg>,
  arrow:   <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>,
  pin:     <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>,
  cog:     <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1A1.7 1.7 0 008 19.4a1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H2a2 2 0 110-4h.1A1.7 1.7 0 003.6 8a1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H8a1.7 1.7 0 001-1.5V2a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V8a1.7 1.7 0 001.5 1H22a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/></svg>,
  signal:  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M5 12.5a8 8 0 0114 0M8 16a4 4 0 018 0M12 19h0"/></svg>,
};

/* ---------- Stage tag ---------- */
const STAGES = [
  { id: 'suggested', label: 'Suggested', short: 'SUG' },
  { id: 'identified', label: 'Identified', short: 'IDN' },
  { id: 'intel_gathered', label: 'Intel gathered', short: 'INT' },
  { id: 'intro_made', label: 'Intro made', short: 'IMD' },
  { id: 'meeting_set', label: 'Meeting set', short: 'MST' },
  { id: 'meeting_done', label: 'Meeting done', short: 'MDN' },
  { id: 'loi_signed', label: 'LOI signed', short: 'LOI' },
  { id: 'onboarded', label: 'Onboarded', short: 'OBD' },
];

Object.assign(window, {
  ZimXMark, Wordmark, IndabaLogo, Eyebrow, Button, Pill, SectorDot, SectorChip, Card, Avatar,
  Phone, PhoneTabs, I, STAGES,
});
