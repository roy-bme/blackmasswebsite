/* AUTH — login (mobile + desktop) */
function AuthLoginMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', padding: '40px 24px 24px', display: 'flex', flexDirection: 'column' }}>
        <IndabaLogo size={22} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', marginTop: -40 }}>
          <Eyebrow gold>indaba / sign in</Eyebrow>
          <h1 style={{ fontSize: 36, fontWeight: 300, letterSpacing: '-0.02em', margin: '12px 0 28px', lineHeight: 1.05 }}>operations portal</h1>
          <Field label="Email" value="brendon@zimx.io" />
          <Field label="Password" value="••••••••••••" />
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 4, marginBottom: 24 }}>
            <a className="mono" style={{ fontSize: 11, color: 'var(--gold)', letterSpacing: '0.14em', textTransform: 'uppercase', textDecoration: 'none' }}>Forgot password</a>
          </div>
          <Button variant="primary" size="lg" fullWidth icon={I.arrow}>Sign in</Button>
        </div>
        <div className="mono" style={{ fontSize: 9, color: 'var(--fg-dim)', letterSpacing: '0.14em', textTransform: 'uppercase', textAlign: 'center' }}>
          Blackmass Enterprises Ltd · v1.0
        </div>
      </div>
    </Phone>
  );
}

function Field({ label, value, focus, hint }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--fg-dim)', marginBottom: 8 }}>{label}</div>
      <div style={{ background: 'var(--ink-700)', border: `1px solid ${focus ? 'var(--gold)' : 'var(--line-15)'}`, padding: '14px 14px', fontSize: 14, color: '#fff' }}>{value}</div>
      {hint ? <div style={{ fontSize: 11, color: 'var(--fg-mute)', marginTop: 6 }}>{hint}</div> : null}
    </div>
  );
}

function AuthLoginDesktop() {
  return (
    <div className="indaba" style={{ width: 1440, height: 900, display: 'flex', flexDirection: 'column' }}>
      <div style={{ height: 56, borderBottom: '1px solid var(--line-10)', display: 'flex', alignItems: 'center', padding: '0 24px' }}>
        <IndabaLogo size={18} />
      </div>
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 64 }}>
          <div style={{ width: 380 }}>
            <Eyebrow gold>indaba / sign in</Eyebrow>
            <h1 style={{ fontSize: 48, fontWeight: 300, letterSpacing: '-0.025em', margin: '14px 0 8px', lineHeight: 1 }}>welcome back.</h1>
            <div style={{ fontSize: 13, color: 'var(--fg-mute)', marginBottom: 28 }}>Sign in to the operations portal.</div>
            <Field label="Email" value="roy@blackmass.co" />
            <Field label="Password" value="••••••••••••" focus />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '4px 0 24px' }}>
              <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--fg-mute)' }}>
                <span style={{ width: 14, height: 14, border: '1px solid var(--line-30)', display: 'inline-block' }} />
                Keep me signed in
              </label>
              <a className="mono" style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>Forgot password</a>
            </div>
            <Button variant="primary" size="lg" fullWidth icon={I.arrow}>Sign in</Button>
            <div style={{ marginTop: 24, fontSize: 11, color: 'var(--fg-dim)', textAlign: 'center' }}>
              Internal tool · access controlled by Blackmass admin
            </div>
          </div>
        </div>
        <div className="map-placeholder" style={{ position: 'relative', borderLeft: '1px solid var(--line-10)' }}>
          <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', padding: 36 }}>
            <Eyebrow gold>bulawayo / 20.1574°S 28.5860°E</Eyebrow>
            <div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>Active pilot</div>
              <div style={{ fontSize: 32, fontWeight: 300, letterSpacing: '-0.02em', marginTop: 6 }}>Bulawayo · ZW</div>
              <div style={{ fontSize: 13, color: 'var(--fg-mute)', marginTop: 6, maxWidth: 360 }}>Mapped 87 businesses · 12 supply-chain links · 3 active loops detected.</div>
            </div>
          </div>
          {/* Sample sector dots */}
          {[[34,42],[58,38],[64,58],[44,66],[72,46],[28,62],[50,50]].map((p,i) => (
            <span key={i} style={{ position:'absolute', left: `${p[0]}%`, top: `${p[1]}%`, width: 10, height: 10, background: ['#BA7517','#E24B4A','#378ADD','#1D9E75','#7F77DD','#D4537E','#E6A83C'][i], boxShadow: '0 0 0 2px rgba(20,22,26,0.6)' }} />
          ))}
        </div>
      </div>
    </div>
  );
}

function AuthErrorMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', padding: 24, display: 'flex', flexDirection: 'column' }}>
        <IndabaLogo size={20} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <Eyebrow style={{ color: 'var(--bad)' }}>auth error / 401</Eyebrow>
          <h1 style={{ fontSize: 28, fontWeight: 300, letterSpacing: '-0.02em', margin: '10px 0 12px', lineHeight: 1.1 }}>can't sign you in.</h1>
          <div style={{ fontSize: 14, color: 'var(--fg-mute)', marginBottom: 24, lineHeight: 1.5 }}>
            Email or password didn't match. Try again, or reset your password if you've forgotten it.
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <Button variant="primary" fullWidth>Try again</Button>
            <Button variant="ghost" fullWidth>Reset password</Button>
          </div>
        </div>
      </div>
    </Phone>
  );
}

window.AuthLoginMobile = AuthLoginMobile;
window.AuthLoginDesktop = AuthLoginDesktop;
window.AuthErrorMobile = AuthErrorMobile;
