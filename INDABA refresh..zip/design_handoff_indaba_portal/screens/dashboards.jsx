/* DASHBOARDS — 4 role variants */

/* === ROY (admin) — Desktop exec dashboard === */
function DashboardRoyDesktop() {
  const sectorMix = [
    { s: 'mining', n: 18 }, { s: 'manufacturing', n: 14 }, { s: 'retail', n: 22 },
    { s: 'services', n: 12 }, { s: 'agriculture', n: 11 }, { s: 'fuel', n: 6 }, { s: 'wholesale', n: 4 },
  ];
  const stages = [
    ['identified', 28], ['intel_gathered', 18], ['intro_made', 14], ['meeting_set', 9],
    ['meeting_done', 7], ['loi_signed', 4], ['onboarded', 7],
  ];
  const total = stages.reduce((a,[,n]) => a+n, 0);
  return (
    <div className="indaba" style={{ width: 1440, height: 900, display: 'grid', gridTemplateColumns: '224px 1fr' }}>
      <DesktopRail role="admin" active="Dashboard" />
      <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <DesktopHeader role="admin" name="Roy" crumbs={['Indaba', 'Dashboard']} />
        <div style={{ flex: 1, padding: 24, overflow: 'hidden' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 18 }}>
            <div>
              <Eyebrow>monday · 27 apr · 2026 · q2 wk17</Eyebrow>
              <h1 style={{ fontSize: 40, fontWeight: 300, letterSpacing: '-0.025em', margin: '6px 0 0', lineHeight: 1 }}>good morning, roy.</h1>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <Pill tone="gold" strong>3 pending approval</Pill>
              <Pill tone="warn">1 reg flag</Pill>
              <Pill tone="ok">agent · idle</Pill>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12, marginBottom: 16 }}>
            <Metric label="Businesses mapped" v="87" sub="+4 this week" />
            <Metric label="Launch 6" v="4/6" sub="onboarded" gold />
            <Metric label="Supply links" v="142" sub="3 loops" />
            <Metric label="Intros · open" v="12" sub="3 awaiting Roy" />
            <Metric label="Events · wk" v="5" sub="2 this week" />
            <Metric label="Agent runs · 24h" v="12" sub="3 new leads" />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16, height: 506 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minHeight: 0 }}>
              <Card padding={20}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
                  <Eyebrow>pipeline funnel</Eyebrow>
                  <Eyebrow style={{ color: 'var(--fg-mute)' }}>{total} total</Eyebrow>
                </div>
                {stages.map(([s,n]) => {
                  const pct = (n/total)*100;
                  return (
                    <div key={s} style={{ marginBottom: 8 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <span className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase' }}>{s.replace('_',' ')}</span>
                        <span className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)' }}>{n}</span>
                      </div>
                      <div style={{ height: 6, background: 'rgba(255,255,255,0.05)' }}>
                        <div style={{ height: '100%', width: `${pct}%`, background: s === 'onboarded' ? 'var(--gold)' : 'rgba(255,255,255,0.5)' }} />
                      </div>
                    </div>
                  );
                })}
              </Card>
              <Card padding={20} style={{ flex: 1, minHeight: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
                  <Eyebrow>launch · 6</Eyebrow>
                  <Eyebrow style={{ color: 'var(--fg-mute)' }}>4/6 onboarded</Eyebrow>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
                  {[
                    ['Mhlanga Mills','agriculture','onboarded'],
                    ['BYO Hardware Co.','retail','onboarded'],
                    ['Khami Logistics','services','onboarded'],
                    ['Ndlovu Steel','manufacturing','onboarded'],
                    ['Imbizo Fuel','fuel','meeting_done'],
                    ['Matabele Mining','mining','intro_made'],
                  ].map(([n,sec,stage]) => (
                    <div key={n} style={{ border: '1px solid var(--line-10)' }}>
                      <div className="placeholder-photo" style={{ height: 56 }}>photo</div>
                      <div style={{ padding: 8 }}>
                        <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 4, lineHeight: 1.2 }}>{n}</div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                          <SectorDot sector={sec} size={6} />
                          <span className="mono" style={{ fontSize: 9, letterSpacing: '0.1em', textTransform: 'uppercase', color: stage==='onboarded' ? 'var(--gold)' : 'var(--fg-mute)' }}>{stage.replace('_',' ')}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minHeight: 0 }}>
              <Card padding={20}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
                  <Eyebrow gold>needs your decision</Eyebrow>
                  <Eyebrow style={{ color: 'var(--fg-mute)' }}>3</Eyebrow>
                </div>
                {[
                  ['Approve intro · Mhlanga Mills', 'Tafadzwa', 'intros'],
                  ['Mark target loop · 4-node manuf chain', 'Agent', 'graph'],
                  ['Confirm event budget · BCCI luncheon', 'Brendon', 'events'],
                ].map(([t,who,m]) => (
                  <div key={t} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderTop: '1px solid var(--line-10)' }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{t}</div>
                      <div className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 3 }}>{who} · {m}</div>
                    </div>
                    <Button variant="ghost" size="sm">Review</Button>
                  </div>
                ))}
              </Card>
              <Card padding={20} style={{ flex: 1, minHeight: 0 }}>
                <Eyebrow style={{ marginBottom: 14 }}>agent · last 24h</Eyebrow>
                <div className="mono" style={{ fontSize: 11, color: 'var(--fg-mute)', lineHeight: 1.9 }}>
                  <div><span style={{color: 'var(--ok)'}}>✓</span> 06:12 · daily_brief generated</div>
                  <div><span style={{color: 'var(--ok)'}}>✓</span> 04:48 · 3 candidates discovered</div>
                  <div><span style={{color: 'var(--warn)'}}>!</span> 02:15 · regulatory ping · RBZ circular 03/26</div>
                  <div><span style={{color: 'var(--ok)'}}>✓</span> 23:40 · supply-chain re-scan · 2 new links</div>
                  <div><span style={{color: 'var(--fg-dim)'}}>·</span> 22:08 · sector watch · mining</div>
                </div>
                <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--line-10)' }}>
                  <Button variant="bare" size="sm">View full console →</Button>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Metric({ label, v, sub, gold }) {
  return (
    <Card padding={14} accent={gold ? 'var(--gold)' : undefined}>
      <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--fg-dim)' }}>{label}</div>
      <div className="mono" style={{ fontSize: 28, fontWeight: 500, letterSpacing: '-0.02em', marginTop: 6, color: gold ? 'var(--gold)' : '#fff' }}>{v}</div>
      {sub ? <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', marginTop: 2 }}>{sub}</div> : null}
    </Card>
  );
}

/* === BRENDON (ops, mobile) — Today === */
function DashboardBrendonMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <PhoneHeader title="today" eyebrow="indaba · ops · brendon" greeting="mon 27 apr · bulawayo" />
        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 110px' }}>
          {/* Map preview tile */}
          <div style={{ position: 'relative', height: 180, marginBottom: 14, border: '1px solid var(--line-10)' }}>
            <div className="map-placeholder" style={{ position: 'absolute', inset: 0 }} />
            {[[28,42],[44,52],[60,38],[68,62],[35,68]].map((p,i) => (
              <span key={i} style={{ position: 'absolute', left: `${p[0]}%`, top: `${p[1]}%`, width: 12, height: 12, background: ['#BA7517','#378ADD','#1D9E75','#E24B4A','#7F77DD'][i], borderRadius: 999, border: '2px solid #14161a' }} />
            ))}
            <span style={{ position: 'absolute', left: '50%', top: '50%', width: 16, height: 16, background: 'var(--gold)', borderRadius: 999, border: '3px solid #14161a', transform: 'translate(-50%,-50%)' }} />
            <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: 12, background: 'linear-gradient(to top, rgba(20,22,26,0.9), transparent)' }}>
              <div className="mono" style={{ fontSize: 9, color: 'var(--fg-dim)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>Today's territory</div>
              <div style={{ fontSize: 14, fontWeight: 500, marginTop: 2 }}>5 visits due · Belmont &amp; Khumalo</div>
            </div>
          </div>

          <Eyebrow gold style={{ marginBottom: 8 }}>visits due — 5</Eyebrow>
          {[
            ['Mhlanga Mills','agriculture','Belmont','last visit 12d ago'],
            ['BYO Hardware','retail','Khumalo','last visit 6d ago'],
            ['Ndlovu Steel','manufacturing','Donnington','intro_made → meeting_set?'],
          ].map(([n,sec,zone,note]) => (
            <Card key={n} padding={14} style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 500 }}>{n}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                    <SectorDot sector={sec} />
                    <span className="mono" style={{ fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--fg-mute)' }}>{sec} · {zone}</span>
                  </div>
                </div>
                <span style={{ color: 'var(--fg-dim)' }}>{I.chevron}</span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--fg-mute)', marginTop: 8 }}>{note}</div>
            </Card>
          ))}

          <Eyebrow style={{ marginTop: 18, marginBottom: 8 }}>roy · in feed · 06:14</Eyebrow>
          <Card padding={14} style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', gap: 10 }}>
              <Avatar name="Roy" gold size={32} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, lineHeight: 1.5 }}>"focus the week on belmont. matabele mining is the priority — chase a meeting before friday."</div>
                <Button variant="bare" size="sm" style={{ marginTop: 8, padding: '4px 0' }}>Reply →</Button>
              </div>
            </div>
          </Card>

          <Card padding={14} style={{ borderColor: 'var(--gold)', borderWidth: 1, borderStyle: 'solid', background: 'rgba(212,175,55,0.05)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ color: 'var(--gold)' }}>{I.mic}</span>
              <Eyebrow gold>agent prompt · end of day</Eyebrow>
            </div>
            <div style={{ fontSize: 13, marginTop: 8 }}>"Anything else worth logging today?" · 30s voice</div>
          </Card>
        </div>
        <PhoneTabs active="Today" tabs={[
          { label: 'Today', icon: I.home },
          { label: 'Map', icon: I.map },
          { label: 'Directory', icon: I.list },
          { label: 'Feed', icon: I.feed, badge: '2' },
        ]} />
      </div>
    </Phone>
  );
}

/* === TAFADZWA (BD, mobile) — This week === */
function DashboardTafadzwaMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <PhoneHeader title="this week" eyebrow="indaba · bd · tafadzwa" greeting="mon 27 apr · bulawayo / hre" />
        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 110px' }}>
          <Eyebrow gold style={{ marginBottom: 10 }}>today · 3 intros</Eyebrow>
          {[
            ['Tendai Moyo','GM, Matabele Mining','warm','meeting today 14:00'],
            ['Sipho Khumalo','Owner, Imbizo Fuel','cold','follow-up email due'],
            ['Memory Dube','BCCI Director','warm','intro to Roy pending'],
          ].map(([n,r,w,note]) => (
            <Card key={n} padding={14} style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: 500 }}>{n}</div>
                  <div style={{ fontSize: 12, color: 'var(--fg-mute)', marginTop: 2 }}>{r}</div>
                </div>
                <Pill tone={w === 'warm' ? 'gold' : 'neutral'}>{w}</Pill>
              </div>
              <div style={{ fontSize: 12, color: 'var(--fg-dim)', marginTop: 8 }}>{note}</div>
            </Card>
          ))}

          <Eyebrow style={{ marginTop: 18, marginBottom: 8 }}>events · this week</Eyebrow>
          {[
            ['BCCI Quarterly Luncheon','Wed · 12:30','rainbow hotel'],
            ['Mining Indaba Africa Mixer','Fri · 18:00','holiday inn'],
          ].map(([t,d,v]) => (
            <Card key={t} padding={14} style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{t}</div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 4 }}>{d} · {v}</div>
                </div>
                <span style={{ width: 6, height: 36, background: 'var(--gold)' }} />
              </div>
            </Card>
          ))}

          <Eyebrow style={{ marginTop: 18, marginBottom: 8 }}>my pipeline · mining · cross-border</Eyebrow>
          <Card padding={14}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
              {[['intel',6],['intro',4],['meeting',2]].map(([s,n]) => (
                <div key={s} style={{ borderTop: '1px solid var(--line-15)', paddingTop: 8 }}>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>{s}</div>
                  <div className="mono" style={{ fontSize: 22, marginTop: 2 }}>{n}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
        <PhoneTabs active="This wk" tabs={[
          { label: 'This wk', icon: I.home },
          { label: 'Intros', icon: I.intros, badge: '3' },
          { label: 'Events', icon: I.events },
          { label: 'Directory', icon: I.list },
          { label: 'Feed', icon: I.feed },
        ]} />
      </div>
    </Phone>
  );
}

/* === VICTOR (Compliance, desktop) === */
function DashboardVictorDesktop() {
  return (
    <div className="indaba" style={{ width: 1440, height: 900, display: 'grid', gridTemplateColumns: '224px 1fr' }}>
      <DesktopRail role="compliance" active="Dashboard" />
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <DesktopHeader role="compliance" name="Victor" crumbs={['Indaba', 'Dashboard']} />
        <div style={{ flex: 1, padding: 24, overflow: 'hidden', display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 16 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <Eyebrow>compliance · queue</Eyebrow>
              <h1 style={{ fontSize: 32, fontWeight: 300, letterSpacing: '-0.02em', margin: '6px 0 0' }}>your queue.</h1>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
              <Metric label="Open" v="7" />
              <Metric label="In review" v="2" />
              <Metric label="Blockers" v="1" gold />
              <Metric label="Resolved · wk" v="14" />
            </div>
            <Card padding={0}>
              <div style={{ padding: 16, borderBottom: '1px solid var(--line-10)' }}>
                <Eyebrow>recent flags · 7 open</Eyebrow>
              </div>
              {[
                ['blocker','KYB · missing source-of-funds','Matabele Mining','agent','12m'],
                ['warning','Cross-border supply link · ZA','Khami Logistics → SA Foods','rule','38m'],
                ['warning','License expiry in 30d','Imbizo Fuel','rule','2h'],
                ['info','Reg signal · RBZ circular 03/26','—','agent','5h'],
                ['warning','PEP screening · review needed','Tendai Moyo (contact)','agent','1d'],
              ].map(([sev,t,sub,src,when]) => (
                <div key={t} style={{ display: 'grid', gridTemplateColumns: '90px 1fr 90px 60px', gap: 12, padding: '12px 16px', borderBottom: '1px solid var(--line-10)', alignItems: 'center' }}>
                  <Pill tone={sev==='blocker'?'bad':sev==='warning'?'warn':'info'}>{sev}</Pill>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{t}</div>
                    <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 3 }}>{sub}</div>
                  </div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{src}</div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)' }}>{when}</div>
                </div>
              ))}
            </Card>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Card padding={20} accent="var(--gold)">
              <Eyebrow gold style={{ marginBottom: 12 }}>agent brief · 06:12</Eyebrow>
              <h2 style={{ fontSize: 22, fontWeight: 400, letterSpacing: '-0.01em', margin: '0 0 12px', lineHeight: 1.25 }}>
                RBZ circular 03/26 introduces revised SI on cross-border merchant remittances.
              </h2>
              <div style={{ fontSize: 13, color: 'var(--fg-mute)', lineHeight: 1.6 }}>
                Three pilot merchants in Bulawayo are exposed: Khami Logistics, Mhlanga Mills, BYO Hardware. Suggested action: refresh KYB on each and confirm source-of-funds attestations before Friday's onboarding window.
              </div>
              <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--line-10)', display: 'flex', gap: 8 }}>
                <Button variant="primary" size="sm">Read full brief</Button>
                <Button variant="ghost" size="sm">Escalate to Roy</Button>
              </div>
            </Card>
            <Card padding={20}>
              <Eyebrow style={{ marginBottom: 12 }}>regulatory signals · 7d</Eyebrow>
              {[
                ['RBZ · circular 03/26','cross-border SI','high'],
                ['FIU · advisory note','PEP screening tightening','med'],
                ['ZRA · tax notice','digital services tax','low'],
              ].map(([s,t,sev]) => (
                <div key={s} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderTop: '1px solid var(--line-10)' }}>
                  <div>
                    <div className="mono" style={{ fontSize: 11, letterSpacing: '0.1em', textTransform: 'uppercase' }}>{s}</div>
                    <div style={{ fontSize: 12, color: 'var(--fg-mute)', marginTop: 2 }}>{t}</div>
                  </div>
                  <Pill tone={sev==='high'?'bad':sev==='med'?'warn':'neutral'}>{sev}</Pill>
                </div>
              ))}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---- Shared chrome ---- */
function PhoneHeader({ title, eyebrow, greeting }) {
  return (
    <div style={{ padding: '8px 16px 14px', borderBottom: '1px solid var(--line-10)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <IndabaLogo size={16} />
        <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
          <span style={{ color: 'var(--fg-dim)' }}>{I.signal}</span>
          <Avatar name={eyebrow?.split('·')[2] || 'XX'} size={26} />
        </div>
      </div>
      <Eyebrow style={{ color: 'var(--gold)' }}>{eyebrow}</Eyebrow>
      <h1 style={{ fontSize: 32, fontWeight: 300, letterSpacing: '-0.025em', margin: '4px 0 4px', lineHeight: 1, textTransform: 'lowercase' }}>{title}</h1>
      {greeting ? <div className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{greeting}</div> : null}
    </div>
  );
}

function DesktopRail({ role, active }) {
  const itemsByRole = {
    admin:      ['Dashboard','Map','Directory','Graph','Intros','Events','Compliance','Agent','Feed'],
    ops:        ['Dashboard','Map','Directory','Feed'],
    bd:         ['Dashboard','Intros','Events','Directory','Feed'],
    compliance: ['Dashboard','Compliance','Agent','Feed'],
  };
  const iconFor = { Dashboard: I.home, Map: I.map, Directory: I.list, Graph: I.graph, Intros: I.intros, Events: I.events, Compliance: I.shield, Agent: I.agent, Feed: I.feed };
  const items = itemsByRole[role] || itemsByRole.admin;
  return (
    <div style={{ background: 'var(--ink-800)', borderRight: '1px solid var(--line-10)', display: 'flex', flexDirection: 'column', padding: '20px 0' }}>
      <div style={{ padding: '0 20px 24px', borderBottom: '1px solid var(--line-10)' }}>
        <IndabaLogo size={18} />
      </div>
      <div style={{ padding: 12, flex: 1 }}>
        <Eyebrow style={{ padding: '12px 8px 6px' }}>navigate</Eyebrow>
        {items.map(it => (
          <div key={it} style={{
            display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px',
            background: it === active ? 'rgba(212,175,55,0.08)' : 'transparent',
            borderLeft: `2px solid ${it === active ? 'var(--gold)' : 'transparent'}`,
            color: it === active ? '#fff' : 'var(--fg-mute)', cursor: 'pointer', marginBottom: 1,
          }}>
            {iconFor[it]}
            <span className="mono" style={{ fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase' }}>{it}</span>
            {it === 'Compliance' && role === 'compliance' ? <Pill tone="bad" style={{ marginLeft: 'auto', fontSize: 9 }}>7</Pill> : null}
            {it === 'Intros' && role === 'admin' ? <Pill tone="gold" style={{ marginLeft: 'auto', fontSize: 9 }}>3</Pill> : null}
            {it === 'Feed' && (role === 'ops' || role === 'admin') ? <Pill style={{ marginLeft: 'auto', fontSize: 9 }}>4</Pill> : null}
          </div>
        ))}
      </div>
      <div style={{ padding: '12px 20px', borderTop: '1px solid var(--line-10)' }}>
        <Eyebrow>settings</Eyebrow>
      </div>
    </div>
  );
}

function DesktopHeader({ role, name, crumbs }) {
  return (
    <div style={{ height: 56, borderBottom: '1px solid var(--line-10)', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <div className="mono" style={{ fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--fg-mute)' }}>
        {crumbs?.map((c,i) => <span key={c}>{i>0 ? <span style={{margin:'0 8px',color:'var(--fg-dim)'}}>/</span> : null}<span style={{color: i === crumbs.length-1 ? '#fff' : 'var(--fg-mute)'}}>{c}</span></span>)}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--ink-800)', border: '1px solid var(--line-15)', padding: '6px 10px', minWidth: 280, color: 'var(--fg-mute)', fontSize: 12 }}>
          <span style={{ color: 'var(--fg-dim)' }}>{I.search}</span>
          <span>businesses, contacts, intros…</span>
          <span className="mono" style={{ marginLeft: 'auto', color: 'var(--fg-dim)', fontSize: 10 }}>⌘K</span>
        </div>
        <Pill tone="gold">{role}</Pill>
        <Avatar name={name} size={30} />
      </div>
    </div>
  );
}

Object.assign(window, {
  DashboardRoyDesktop, DashboardBrendonMobile, DashboardTafadzwaMobile, DashboardVictorDesktop,
  Metric, PhoneHeader, DesktopRail, DesktopHeader,
});
