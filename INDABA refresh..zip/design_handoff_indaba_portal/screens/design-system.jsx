/* Design system reference card */
function DesignSystem() {
  const swatch = (label, color, hex) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ width: '100%', height: 56, background: color, border: '1px solid var(--line-10)' }} />
      <div className="mono" style={{ fontSize: 10, color: 'var(--fg)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{label}</div>
      <div className="mono" style={{ fontSize: 9, color: 'var(--fg-dim)', letterSpacing: '0.06em' }}>{hex}</div>
    </div>
  );

  return (
    <div className="indaba" style={{ width: 1280, padding: 48, background: 'var(--ink-700)' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 36, paddingBottom: 20, borderBottom: '1px solid var(--line-15)' }}>
        <div>
          <Eyebrow gold>Indaba / Design System / v1</Eyebrow>
          <h1 style={{ fontSize: 56, fontWeight: 300, letterSpacing: '-0.03em', margin: '12px 0 0', lineHeight: 1 }}>operations portal</h1>
          <div style={{ fontSize: 14, color: 'var(--fg-mute)', marginTop: 12, maxWidth: 580 }}>
            Bloomberg-terminal density with breathing room. Dark ink ground, gold for emphasis only, mono for everything operational — labels, eyebrows, metrics, timestamps, IDs.
          </div>
        </div>
        <IndabaLogo size={20} />
      </div>

      {/* Color */}
      <Eyebrow gold style={{ marginBottom: 14 }}>§ 01 — color</Eyebrow>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 12, marginBottom: 14 }}>
        {swatch('ink-900', '#14161a', '#14161A')}
        {swatch('ink-700 / bg', '#1f2228', '#1F2228')}
        {swatch('ink-600', '#262a31', '#262A31')}
        {swatch('ink-500', '#2f343c', '#2F343C')}
        {swatch('line-15', 'rgba(255,255,255,0.12)', 'WHITE/12')}
        {swatch('fg', '#ffffff', '#FFFFFF')}
        {swatch('fg-mute', 'rgba(255,255,255,0.62)', 'WHITE/62')}
        {swatch('gold', '#d4af37', '#D4AF37')}
      </div>
      <Eyebrow style={{ marginBottom: 8 }}>sectors — for data-viz only, used sparingly</Eyebrow>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 12, marginBottom: 14 }}>
        {swatch('mining', 'var(--sec-mining)', '#BA7517')}
        {swatch('manufacturing', 'var(--sec-manufacturing)', '#E24B4A')}
        {swatch('retail / wholesale', 'var(--sec-retail)', '#378ADD')}
        {swatch('services', 'var(--sec-services)', '#7F77DD')}
        {swatch('agriculture / fmcg', 'var(--sec-agriculture)', '#1D9E75')}
        {swatch('fuel', 'var(--sec-fuel)', '#D4537E')}
        {swatch('warn', 'var(--warn)', '#E6A83C')}
        {swatch('bad', 'var(--bad)', '#E2614B')}
      </div>

      {/* Type */}
      <div style={{ marginTop: 32 }}>
        <Eyebrow gold style={{ marginBottom: 14 }}>§ 02 — typography</Eyebrow>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32 }}>
          <Card padding={24}>
            <Eyebrow style={{ marginBottom: 16 }}>Inter — sans, body & display</Eyebrow>
            <div style={{ fontSize: 56, fontWeight: 300, letterSpacing: '-0.03em', lineHeight: 1.05, marginBottom: 8 }}>display 56 / 300</div>
            <div style={{ fontSize: 32, fontWeight: 300, letterSpacing: '-0.02em', marginBottom: 8 }}>heading 32 / 300</div>
            <div style={{ fontSize: 20, fontWeight: 500, marginBottom: 8 }}>title 20 / 500</div>
            <div style={{ fontSize: 14, color: 'var(--fg-mute)' }}>body 14 / 400 — high information density on desktop, generous on mobile.</div>
            <div style={{ fontSize: 12, color: 'var(--fg-dim)', marginTop: 4 }}>caption 12 / 400</div>
          </Card>
          <Card padding={24}>
            <Eyebrow style={{ marginBottom: 16 }}>JetBrains Mono — labels, metrics, ids</Eyebrow>
            <div className="mono" style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--fg-dim)', marginBottom: 8 }}>EYEBROW · 11 / 0.18EM · UPPERCASE</div>
            <div className="mono" style={{ fontSize: 32, letterSpacing: '-0.02em', marginBottom: 8 }}>87 · 12 · 4.2k</div>
            <div className="mono" style={{ fontSize: 13, color: 'var(--fg-mute)', marginBottom: 8 }}>ID — 0x9F2A · 19:32 GMT+2</div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--fg-dim)', letterSpacing: '0.06em' }}>2026-04-27 · agent.run.daily_brief</div>
          </Card>
        </div>
      </div>

      {/* Components */}
      <div style={{ marginTop: 32 }}>
        <Eyebrow gold style={{ marginBottom: 14 }}>§ 03 — components</Eyebrow>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <Card padding={20}>
            <Eyebrow style={{ marginBottom: 14 }}>Buttons</Eyebrow>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 12 }}>
              <Button variant="primary">Approve</Button>
              <Button variant="solid">Continue</Button>
              <Button variant="ghost">Cancel</Button>
              <Button variant="bare">Skip</Button>
              <Button variant="danger">Escalate</Button>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              <Button variant="ghost" size="sm">SM</Button>
              <Button variant="ghost" size="md">MD</Button>
              <Button variant="ghost" size="lg">LG</Button>
              <Button variant="ghost" icon={I.plus}>Add</Button>
            </div>
          </Card>

          <Card padding={20}>
            <Eyebrow style={{ marginBottom: 14 }}>Pills</Eyebrow>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              <Pill>neutral</Pill>
              <Pill tone="gold">gold · pending</Pill>
              <Pill tone="ok">resolved</Pill>
              <Pill tone="warn">warning</Pill>
              <Pill tone="bad">blocker</Pill>
              <Pill tone="info">info</Pill>
              <Pill tone="solid">launch 6</Pill>
              <Pill tone="gold" strong>approved</Pill>
            </div>
            <div style={{ height: 16 }} />
            <Eyebrow style={{ marginBottom: 10 }}>Sector chips</Eyebrow>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              <SectorChip sector="mining" active />
              <SectorChip sector="manufacturing" />
              <SectorChip sector="retail" />
              <SectorChip sector="services" />
              <SectorChip sector="agriculture" />
              <SectorChip sector="fuel" />
            </div>
          </Card>

          <Card padding={20}>
            <Eyebrow style={{ marginBottom: 14 }}>Inputs</Eyebrow>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--fg-dim)', textTransform: 'uppercase', marginBottom: 6 }}>Email</div>
                <div style={{ background: 'var(--ink-700)', border: '1px solid var(--line-15)', padding: '10px 12px', fontSize: 13, color: '#fff' }}>brendon@zimx.io</div>
              </div>
              <div>
                <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--fg-dim)', textTransform: 'uppercase', marginBottom: 6 }}>Search</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--ink-700)', border: '1px solid var(--line-15)', padding: '10px 12px', color: 'var(--fg-mute)', fontSize: 13 }}>
                  <span style={{ color: 'var(--fg-dim)' }}>{I.search}</span>
                  <span>businesses, contacts, intros…</span>
                </div>
              </div>
              <div>
                <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--fg-dim)', textTransform: 'uppercase', marginBottom: 6 }}>Notes (focused)</div>
                <div style={{ background: 'var(--ink-700)', border: '1px solid var(--gold)', padding: '10px 12px', fontSize: 13, color: '#fff', minHeight: 60 }}>kept it warm — owner travelling, returns Friday.</div>
              </div>
            </div>
          </Card>

          <Card padding={20}>
            <Eyebrow style={{ marginBottom: 14 }}>Empty / loading / error states</Eyebrow>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
              <div style={{ border: '1px dashed var(--line-15)', padding: 14, minHeight: 130 }}>
                <div className="mono" style={{ fontSize: 9, color: 'var(--fg-dim)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>Empty</div>
                <div style={{ fontSize: 13, marginTop: 8 }}>Queue is clear.</div>
                <div style={{ fontSize: 11, color: 'var(--fg-mute)', marginTop: 4 }}>The agent will surface items here as it finds them.</div>
              </div>
              <div style={{ border: '1px solid var(--line-10)', padding: 14, minHeight: 130 }}>
                <div className="skeleton" style={{ height: 10, width: '60%', marginBottom: 10 }} />
                <div className="skeleton" style={{ height: 10, width: '90%', marginBottom: 8 }} />
                <div className="skeleton" style={{ height: 10, width: '75%', marginBottom: 8 }} />
                <div className="skeleton" style={{ height: 10, width: '40%' }} />
              </div>
              <div style={{ border: '1px solid rgba(226,97,75,0.30)', background: 'rgba(226,97,75,0.06)', padding: 14, minHeight: 130 }}>
                <div className="mono" style={{ fontSize: 9, color: 'var(--bad)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>Error</div>
                <div style={{ fontSize: 13, marginTop: 8 }}>Couldn't load directory.</div>
                <div style={{ fontSize: 11, color: 'var(--fg-mute)', marginTop: 4, marginBottom: 10 }}>Connection dropped. Try again.</div>
                <Button variant="ghost" size="sm" icon={I.refresh}>Retry</Button>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Spacing & rules */}
      <div style={{ marginTop: 32 }}>
        <Eyebrow gold style={{ marginBottom: 14 }}>§ 04 — rules</Eyebrow>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          {[
            { k: 'Radius', v: '0px default · 2px on overlays only' },
            { k: 'Borders', v: 'hairline white/10 · 15 · 20 only' },
            { k: 'Spacing', v: '4 · 8 · 12 · 16 · 24 · 32 · 48' },
            { k: 'Density', v: 'desktop tight · mobile generous' },
            { k: 'Voice', v: 'terse · operational · lowercase' },
            { k: 'Mono usage', v: 'labels · ids · timestamps · metrics' },
            { k: 'Gold usage', v: 'primary action · pending state' },
            { k: 'No emoji', v: 'sector dots only for visual variety' },
          ].map((r) => (
            <div key={r.k} style={{ borderTop: '1px solid var(--line-15)', paddingTop: 10 }}>
              <div className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', color: 'var(--fg-dim)', textTransform: 'uppercase' }}>{r.k}</div>
              <div style={{ fontSize: 13, marginTop: 4 }}>{r.v}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

window.DesignSystem = DesignSystem;
