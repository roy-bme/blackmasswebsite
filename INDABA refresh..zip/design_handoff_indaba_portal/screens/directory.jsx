/* DIRECTORY — kanban (desktop) + swipe lanes (mobile) + Suggested */

const SAMPLE_BUSINESSES = {
  suggested: [
    { name: 'Hwange Coal Traders', sector: 'mining', meta: 'agent · 92% match', confidence: 92 },
    { name: 'Zambezi Cotton Co.', sector: 'agriculture', meta: 'agent · supply link signal', confidence: 78 },
    { name: 'Bulawayo Brake Pads', sector: 'manufacturing', meta: 'agent · web mention', confidence: 64 },
  ],
  identified: [
    { name: 'Matabele Mining Ltd', sector: 'mining', meta: '4 contacts · belmont', l6: true },
    { name: 'Khumalo Spares', sector: 'retail', meta: '1 contact' },
    { name: 'Donnington Foundry', sector: 'manufacturing', meta: '2 contacts' },
  ],
  intel_gathered: [
    { name: 'Imbizo Fuel', sector: 'fuel', meta: 'mapped · sof pending', l6: true },
    { name: 'Ascot Agro', sector: 'agriculture', meta: 'mapped · 3 visits' },
  ],
  intro_made: [
    { name: 'Ndlovu Steel Works', sector: 'manufacturing', meta: 'intro · 12 apr', l6: true },
    { name: 'Memory Logistics', sector: 'services', meta: 'intro · 19 apr' },
  ],
  meeting_set: [
    { name: 'BYO Hardware Co.', sector: 'retail', meta: 'fri 14:00', l6: true },
  ],
  meeting_done: [
    { name: 'Khami Logistics', sector: 'services', meta: 'kept warm', l6: true },
  ],
  loi_signed: [
    { name: 'Mhlanga Mills', sector: 'agriculture', meta: 'signed 22 apr', l6: true },
  ],
  onboarded: [
    { name: 'Belmont FMCG', sector: 'fmcg', meta: 'live · 18 apr' },
  ],
};

function BizCard({ b, suggested }) {
  return (
    <div style={{
      background: 'var(--ink-700)',
      border: `1px solid ${suggested ? 'rgba(212,175,55,0.25)' : 'var(--line-10)'}`,
      borderLeft: `2px solid var(--sec-${b.sector})`,
      padding: 10, marginBottom: 6,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 500, lineHeight: 1.25 }}>{b.name}</div>
          <div className="mono" style={{ fontSize: 9, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 4 }}>{b.meta}</div>
        </div>
        {b.l6 ? <Pill tone="solid" style={{ fontSize: 8, padding: '2px 5px' }}>L6</Pill> : null}
      </div>
      {suggested ? (
        <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid var(--line-10)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span className="mono" style={{ fontSize: 9, color: 'var(--gold)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>{b.confidence}% conf.</span>
          <Button variant="primary" size="sm" style={{ fontSize: 9, padding: '4px 8px' }}>Promote</Button>
        </div>
      ) : null}
    </div>
  );
}

function DirectoryDesktop() {
  const lanes = [
    { id: 'suggested', label: 'Suggested', subtitle: 'agent', isAgent: true },
    { id: 'identified', label: 'Identified' },
    { id: 'intel_gathered', label: 'Intel gathered' },
    { id: 'intro_made', label: 'Intro made' },
    { id: 'meeting_set', label: 'Meeting set' },
    { id: 'meeting_done', label: 'Meeting done' },
    { id: 'loi_signed', label: 'LOI signed' },
    { id: 'onboarded', label: 'Onboarded' },
  ];
  return (
    <div className="indaba" style={{ width: 1440, height: 900, display: 'grid', gridTemplateColumns: '224px 1fr' }}>
      <DesktopRail role="admin" active="Directory" />
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <DesktopHeader role="admin" name="Roy" crumbs={['Indaba', 'Directory']} />
        <div style={{ padding: '16px 24px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--line-10)' }}>
          <div>
            <Eyebrow>directory · pipeline</Eyebrow>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 4 }}>
              <h1 style={{ fontSize: 24, fontWeight: 400, margin: 0, letterSpacing: '-0.01em' }}>87 businesses</h1>
              <span className="mono" style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>+ 3 suggested · 4 onboarded</span>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <SectorChip sector="mining" active /><SectorChip sector="manufacturing" /><SectorChip sector="retail" /><SectorChip sector="agriculture" />
            <Button variant="ghost" size="sm">Launch 6</Button>
            <Button variant="ghost" size="sm">Show only mine</Button>
            <Button variant="primary" size="sm" icon={I.plus}>Add</Button>
          </div>
        </div>

        <div className="thin-scroll" style={{ flex: 1, overflowX: 'auto', padding: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 230px)', gap: 8, height: '100%' }}>
            {lanes.map((l) => {
              const items = SAMPLE_BUSINESSES[l.id] || [];
              return (
                <div key={l.id} style={{
                  background: l.isAgent ? 'rgba(212,175,55,0.04)' : 'var(--ink-800)',
                  border: `1px solid ${l.isAgent ? 'rgba(212,175,55,0.25)' : 'var(--line-10)'}`,
                  display: 'flex', flexDirection: 'column', minHeight: 0,
                }}>
                  <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--line-10)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span className="mono" style={{ fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', color: l.isAgent ? 'var(--gold)' : '#fff' }}>{l.label}</span>
                    <span className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)' }}>{items.length}</span>
                  </div>
                  <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: 8 }}>
                    {items.length === 0 ? (
                      <div style={{ border: '1px dashed var(--line-15)', padding: 12, fontSize: 11, color: 'var(--fg-mute)', lineHeight: 1.4 }}>
                        Empty. Move one from "{lanes[Math.max(0, lanes.findIndex(x=>x.id===l.id)-1)]?.label}" when ready.
                      </div>
                    ) : items.map((b) => <BizCard key={b.name} b={b} suggested={l.isAgent} />)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function DirectoryMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <PhoneHeader title="directory" eyebrow="indaba · pipeline · brendon" greeting="87 businesses · 3 suggested" />
        {/* Stage swiper */}
        <div style={{ padding: '12px 16px 8px', borderBottom: '1px solid var(--line-10)' }}>
          <div className="thin-scroll" style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 4 }}>
            {STAGES.map((s) => (
              <span key={s.id} style={{
                padding: '6px 10px', whiteSpace: 'nowrap',
                border: `1px solid ${s.id === 'intro_made' ? 'var(--gold)' : 'var(--line-15)'}`,
                background: s.id === 'intro_made' ? 'rgba(212,175,55,0.1)' : (s.id === 'suggested' ? 'rgba(212,175,55,0.04)' : 'transparent'),
                fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase',
                color: s.id === 'intro_made' ? 'var(--gold)' : (s.id === 'suggested' ? 'var(--gold)' : 'var(--fg-mute)'),
              }}>{s.label}</span>
            ))}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
            <span className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>4 of 8 · swipe lanes</span>
            <span className="mono" style={{ fontSize: 10, color: 'var(--gold)' }}>2 in lane</span>
          </div>
        </div>

        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 16px 90px' }}>
          {SAMPLE_BUSINESSES.intro_made.map((b) => (
            <Card key={b.name} padding={14} style={{ marginBottom: 8, borderLeft: `2px solid var(--sec-${b.sector})` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: 16, fontWeight: 500 }}>{b.name}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
                    <SectorDot sector={b.sector} />
                    <span className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>{b.sector} · {b.meta}</span>
                  </div>
                </div>
                {b.l6 ? <Pill tone="solid">L6</Pill> : null}
              </div>
            </Card>
          ))}
          {/* Empty state demo */}
          <div style={{ marginTop: 16 }}>
            <Eyebrow>example empty lane — meeting set</Eyebrow>
            <div style={{ border: '1px dashed var(--line-15)', padding: 18, marginTop: 10 }}>
              <div className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>empty</div>
              <div style={{ fontSize: 14, marginTop: 6 }}>No businesses in 'meeting set'.</div>
              <div style={{ fontSize: 12, color: 'var(--fg-mute)', marginTop: 4 }}>Move one from 'intro made' when a meeting's booked.</div>
            </div>
          </div>
        </div>
        <PhoneTabs active="Directory" tabs={[
          { label: 'Today', icon: I.home },
          { label: 'Map', icon: I.map },
          { label: 'Directory', icon: I.list },
          { label: 'Feed', icon: I.feed },
        ]} />
      </div>
    </Phone>
  );
}

window.DirectoryDesktop = DirectoryDesktop;
window.DirectoryMobile = DirectoryMobile;
