/* GRAPH — supply chain SVG (desktop) + list view (mobile) */
function GraphDesktop() {
  const layers = [
    { y: 130, label: 'mining', color: 'var(--sec-mining)' },
    { y: 280, label: 'manufacturing', color: 'var(--sec-manufacturing)' },
    { y: 430, label: 'wholesale / retail', color: 'var(--sec-retail)' },
    { y: 580, label: 'services', color: 'var(--sec-services)' },
  ];
  const nodes = [
    { x: 180, y: 130, l: 'Matabele Mining', s: 'mining' },
    { x: 380, y: 130, l: 'Hwange Coal', s: 'mining' },
    { x: 580, y: 130, l: 'Bulawayo Quarry', s: 'mining' },
    { x: 240, y: 280, l: 'Ndlovu Steel', s: 'manufacturing', loop: true },
    { x: 460, y: 280, l: 'Donnington Foundry', s: 'manufacturing', loop: true },
    { x: 660, y: 280, l: 'Bulawayo Brake', s: 'manufacturing' },
    { x: 200, y: 430, l: 'BYO Hardware', s: 'retail', loop: true },
    { x: 440, y: 430, l: 'Khumalo Spares', s: 'retail' },
    { x: 640, y: 430, l: 'Belmont Mart', s: 'retail' },
    { x: 320, y: 580, l: 'Khami Logistics', s: 'services', loop: true },
    { x: 540, y: 580, l: 'Memory Logistics', s: 'services' },
  ];
  const edges = [
    [0,3],[1,3],[1,4],[2,5],[3,6],[3,7],[4,7],[4,8],[5,8],
    [6,9],[7,9],[7,10],[8,10], [9,3], // loop edge back
  ];
  return (
    <div className="indaba" style={{ width: 1440, height: 900, display: 'grid', gridTemplateColumns: '224px 1fr 320px' }}>
      <DesktopRail role="admin" active="Graph" />
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <DesktopHeader role="admin" name="Roy" crumbs={['Indaba', 'Graph']} />
        <div style={{ padding: '14px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--line-10)' }}>
          <div>
            <Eyebrow>supply-chain graph · 142 links · 3 loops</Eyebrow>
            <h1 style={{ fontSize: 22, fontWeight: 400, margin: '4px 0 0' }}>bulawayo · pilot</h1>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {layers.map(l => <SectorChip key={l.label} sector={l.label.split(' ')[0]} active />)}
            <Button variant="primary" size="sm">Detect loops</Button>
          </div>
        </div>
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: 'var(--ink-700)' }}>
          <svg viewBox="0 0 880 700" style={{ width: '100%', height: '100%' }}>
            {/* Layer rails */}
            {layers.map(l => (
              <g key={l.label}>
                <line x1="40" y1={l.y} x2="840" y2={l.y} stroke={l.color} strokeOpacity="0.1" strokeDasharray="2 6" />
                <text x="40" y={l.y - 18} fill={l.color} fontFamily="var(--mono)" fontSize="10" letterSpacing="2">{l.label.toUpperCase()}</text>
              </g>
            ))}
            {/* Edges */}
            {edges.map(([a,b],i) => {
              const A = nodes[a], B = nodes[b];
              const isLoop = A.loop && B.loop;
              return <path key={i} d={`M ${A.x} ${A.y} Q ${(A.x+B.x)/2} ${(A.y+B.y)/2 - 30} ${B.x} ${B.y}`} stroke={isLoop ? 'var(--gold)' : 'rgba(255,255,255,0.18)'} strokeWidth={isLoop ? 1.6 : 1} fill="none" />;
            })}
            {/* Nodes */}
            {nodes.map((n,i) => (
              <g key={i}>
                <circle cx={n.x} cy={n.y} r="10" fill={`var(--sec-${n.s})`} stroke={n.loop ? 'var(--gold)' : '#14161a'} strokeWidth={n.loop ? 2 : 2} />
                <text x={n.x} y={n.y + 26} fill="#fff" fontFamily="Inter" fontSize="11" textAnchor="middle">{n.l}</text>
              </g>
            ))}
          </svg>
        </div>
      </div>

      <div style={{ background: 'var(--ink-800)', borderLeft: '1px solid var(--line-10)', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: 20, borderBottom: '1px solid var(--line-10)' }}>
          <Eyebrow gold>loops detected · 3</Eyebrow>
        </div>
        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
          {[
            { name: 'Steel-Hardware loop', chain: ['Matabele Mining','Ndlovu Steel','BYO Hardware','Khami Logistics'], usd: 18400, target: true },
            { name: 'Foundry triangle', chain: ['Hwange Coal','Donnington Foundry','BYO Hardware','Khami Logistics','Ndlovu Steel'], usd: 24600 },
            { name: 'Cross-zone loop', chain: ['Bulawayo Quarry','Bulawayo Brake','Belmont Mart','Memory Logistics'], usd: 9100 },
          ].map((l) => (
            <div key={l.name} style={{ border: '1px solid rgba(212,175,55,0.25)', background: 'rgba(212,175,55,0.04)', padding: 14, marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--gold)' }}>{l.name}</div>
                {l.target ? <Pill tone="gold" strong style={{ fontSize: 9 }}>target</Pill> : null}
              </div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', marginTop: 6, letterSpacing: '0.05em', lineHeight: 1.5 }}>{l.chain.join(' → ')}</div>
              <div className="mono" style={{ fontSize: 11, color: 'var(--gold)', marginTop: 8, letterSpacing: '0.08em' }}>${l.usd.toLocaleString()} / mo</div>
              {!l.target ? <div style={{ marginTop: 10 }}><Button variant="ghost" size="sm">Mark as target</Button></div> : null}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function GraphMobileList() {
  const groups = [
    { supplier: 'Matabele Mining', sector: 'mining', children: [['Ndlovu Steel','manufacturing','$4.2k/mo'],['Donnington Foundry','manufacturing','$3.1k/mo']] },
    { supplier: 'Ndlovu Steel', sector: 'manufacturing', children: [['BYO Hardware','retail','$6.4k/mo'],['Khumalo Spares','retail','$2.8k/mo']] },
    { supplier: 'BYO Hardware', sector: 'retail', children: [['Khami Logistics','services','$1.9k/mo']] },
  ];
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <PhoneHeader title="supply chain" eyebrow="indaba · graph · list view" greeting="142 links · 3 loops" />
        <div style={{ padding: '10px 16px', display: 'flex', gap: 6, borderBottom: '1px solid var(--line-10)' }}>
          <Pill tone="gold">List</Pill>
          <Pill>Graph</Pill>
          <Button variant="ghost" size="sm" style={{ marginLeft: 'auto' }}>Detect loops</Button>
        </div>
        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 16px 90px' }}>
          <Eyebrow gold style={{ marginBottom: 10 }}>loops · 3</Eyebrow>
          <Card padding={14} style={{ borderColor: 'rgba(212,175,55,0.3)', background: 'rgba(212,175,55,0.05)', marginBottom: 14 }}>
            <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--gold)' }}>Steel-Hardware loop</div>
            <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', marginTop: 6, letterSpacing: '0.05em', lineHeight: 1.5 }}>Matabele Mining → Ndlovu Steel → BYO Hardware → Khami Logistics</div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--gold)', marginTop: 8 }}>$18,400 / mo</div>
          </Card>
          <Eyebrow style={{ marginBottom: 10 }}>by supplier</Eyebrow>
          {groups.map((g) => (
            <Card key={g.supplier} padding={14} style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <SectorDot sector={g.sector} />
                <div style={{ fontSize: 14, fontWeight: 500 }}>{g.supplier}</div>
                <span className="mono" style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--fg-mute)' }}>{g.children.length} links</span>
              </div>
              <div style={{ marginTop: 10, paddingLeft: 16, borderLeft: '1px dashed var(--line-15)' }}>
                {g.children.map(([n,s,v]) => (
                  <div key={n} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <SectorDot sector={s} size={6} />
                      <span style={{ fontSize: 12 }}>{n}</span>
                    </span>
                    <span className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)' }}>{v}</span>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
        <PhoneTabs active="Graph" tabs={[
          { label: 'Today', icon: I.home }, { label: 'Map', icon: I.map },
          { label: 'Directory', icon: I.list }, { label: 'Graph', icon: I.graph }, { label: 'Feed', icon: I.feed },
        ]} />
      </div>
    </Phone>
  );
}

window.GraphDesktop = GraphDesktop;
window.GraphMobileList = GraphMobileList;
