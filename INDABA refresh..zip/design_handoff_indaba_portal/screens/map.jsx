/* MAP — Brendon's home (mobile + desktop) */
function MapMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', position: 'relative', overflow: 'hidden' }}>
        <div className="map-placeholder" style={{ position: 'absolute', inset: 0 }} />
        {/* Zone polygons (faux) */}
        <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
          <polygon points="40,140 140,120 200,200 130,260 50,240" fill="rgba(212,175,55,0.06)" stroke="var(--gold)" strokeOpacity="0.4" strokeDasharray="4 3"/>
          <polygon points="200,300 320,280 340,400 240,440" fill="rgba(120,148,200,0.05)" stroke="rgba(120,148,200,0.3)" strokeDasharray="4 3"/>
          {/* supply chain polylines */}
          <path d="M 80,180 L 170,260 L 260,330" stroke="rgba(255,255,255,0.25)" strokeWidth="1.2" fill="none" strokeDasharray="2 4"/>
          <path d="M 280,150 L 220,200 L 170,260" stroke="rgba(255,255,255,0.25)" strokeWidth="1.2" fill="none" strokeDasharray="2 4"/>
        </svg>
        {/* sector markers + numbered task pins */}
        {[
          [80,180,'mining',1],[170,260,'manufacturing',2],[260,330,'agriculture',3],
          [280,150,'retail',null],[100,330,'services',null],[300,420,'fuel',4],[60,420,'retail',5],
        ].map(([x,y,s,n],i) => (
          <span key={i} style={{ position: 'absolute', left: x-7, top: y-7, width: 14, height: 14, borderRadius: 999, background: `var(--sec-${s})`, border: '2px solid #14161a', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--mono)', fontSize: 9, fontWeight: 700, color: '#14161a' }}>
            {n}
          </span>
        ))}
        {/* User location */}
        <span style={{ position: 'absolute', left: 165, top: 235, width: 18, height: 18, background: 'var(--gold)', borderRadius: 999, border: '3px solid #14161a', boxShadow: '0 0 0 6px rgba(212,175,55,0.18)' }} />

        {/* Top floating header */}
        <div style={{ position: 'absolute', top: 14, left: 14, right: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ background: 'rgba(20,22,26,0.85)', backdropFilter: 'blur(10px)', border: '1px solid var(--line-15)', padding: '8px 12px' }}>
            <Eyebrow gold>territory · today</Eyebrow>
            <div style={{ fontSize: 12, marginTop: 2 }}>5 visits · 2 zones</div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <span style={{ width: 36, height: 36, background: 'rgba(20,22,26,0.85)', border: '1px solid var(--line-15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{I.filter}</span>
          </div>
        </div>

        {/* Floating + */}
        <span style={{ position: 'absolute', right: 18, bottom: 280, width: 56, height: 56, background: 'var(--gold)', color: '#1a1612', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 8px 32px rgba(0,0,0,0.5)' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>
        </span>

        {/* Bottom sheet — selected business */}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: 'var(--ink-800)', borderTop: '1px solid var(--line-15)' }}>
          <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0' }}>
            <span style={{ width: 36, height: 3, background: 'var(--line-30)' }} />
          </div>
          <div style={{ padding: '0 16px 14px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <SectorDot sector="manufacturing" />
                  <Eyebrow>manufacturing · donnington</Eyebrow>
                </div>
                <div style={{ fontSize: 18, fontWeight: 500 }}>Ndlovu Steel Works</div>
                <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 4 }}>9 Forge Rd · 2.4 km · last visit 6d</div>
              </div>
              <Pill tone="gold">intro made</Pill>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6, marginTop: 14 }}>
              <Button variant="primary" size="sm" icon={I.mic}>Log visit</Button>
              <Button variant="ghost" size="sm">Detail</Button>
              <Button variant="ghost" size="sm">Directions</Button>
            </div>
          </div>
        </div>
      </div>
    </Phone>
  );
}

function MapMobilePinDrop() {
  return (
    <Phone>
      <div className="indaba indaba-pin-drop-cursor" style={{ height: '100%', position: 'relative', overflow: 'hidden' }}>
        <div className="map-placeholder" style={{ position: 'absolute', inset: 0, opacity: 0.5 }} />
        <div style={{ position: 'absolute', inset: 0, background: 'rgba(20,22,26,0.4)' }} />
        {/* crosshair */}
        <span style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', width: 60, height: 60, border: '1px solid var(--gold)', borderRadius: 999 }} />
        <span style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', width: 2, height: 16, background: 'var(--gold)' }} />
        <span style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', width: 16, height: 2, background: 'var(--gold)' }} />

        <div style={{ position: 'absolute', top: 14, left: 14, right: 14, background: 'rgba(20,22,26,0.92)', border: '1px solid var(--gold)', padding: 14 }}>
          <Eyebrow gold>pin-drop · step 1 of 2</Eyebrow>
          <div style={{ fontSize: 14, marginTop: 6 }}>Centre the crosshair, then tap to drop a pin.</div>
        </div>

        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, background: 'linear-gradient(to top, rgba(20,22,26,0.95), transparent)' }}>
          <div style={{ display: 'flex', gap: 8 }}>
            <Button variant="ghost" fullWidth>Cancel</Button>
            <Button variant="primary" fullWidth icon={I.pin}>Drop here</Button>
          </div>
        </div>
      </div>
    </Phone>
  );
}

function MapDesktop() {
  return (
    <div className="indaba" style={{ width: 1440, height: 900, display: 'grid', gridTemplateColumns: '224px 1fr 360px' }}>
      <DesktopRail role="ops" active="Map" />
      <div style={{ position: 'relative', overflow: 'hidden' }}>
        <div style={{ height: 56, borderBottom: '1px solid var(--line-10)', padding: '0 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div className="mono" style={{ fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--fg-mute)' }}>indaba <span style={{ color: 'var(--fg-dim)', margin: '0 8px' }}>/</span> <span style={{ color: '#fff' }}>map</span></div>
          <div style={{ display: 'flex', gap: 6 }}>
            <SectorChip sector="mining" active /><SectorChip sector="manufacturing" active /><SectorChip sector="retail" active /><SectorChip sector="services" /><SectorChip sector="agriculture" active /><SectorChip sector="fuel" />
          </div>
        </div>
        <div className="map-placeholder" style={{ position: 'absolute', top: 56, bottom: 0, left: 0, right: 0 }} />
        <svg style={{ position: 'absolute', top: 56, left: 0, right: 0, bottom: 0, width: '100%' }}>
          <polygon points="120,120 320,80 420,260 280,400 100,360" fill="rgba(212,175,55,0.05)" stroke="var(--gold)" strokeOpacity="0.4" strokeDasharray="6 4"/>
          <polygon points="500,300 720,260 760,500 540,540" fill="rgba(120,148,200,0.04)" stroke="rgba(120,148,200,0.3)" strokeDasharray="6 4"/>
          <path d="M 200,200 L 360,300 L 540,400" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" fill="none" strokeDasharray="3 5"/>
          <path d="M 600,200 L 460,260 L 360,300" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" fill="none" strokeDasharray="3 5"/>
          <path d="M 360,300 L 280,440" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" fill="none" strokeDasharray="3 5"/>
        </svg>
        {/* markers */}
        {[[200,200,'mining'],[360,300,'manufacturing'],[540,400,'agriculture'],[600,200,'retail'],[460,260,'wholesale'],[280,440,'services'],[700,360,'fuel'],[150,400,'manufacturing']].map(([x,y,s],i) => (
          <span key={i} style={{ position: 'absolute', left: x-8, top: y+56-8, width: 16, height: 16, borderRadius: 999, background: `var(--sec-${s})`, border: '2px solid #14161a' }} />
        ))}
        {/* diamond intro markers */}
        {[[420,160],[640,440]].map(([x,y],i) => (
          <span key={i} style={{ position: 'absolute', left: x-7, top: y+56-7, width: 14, height: 14, background: 'var(--gold)', transform: 'rotate(45deg)', border: '2px solid #14161a' }} />
        ))}

        {/* Legend */}
        <div style={{ position: 'absolute', left: 20, bottom: 20, background: 'rgba(20,22,26,0.9)', border: '1px solid var(--line-15)', padding: '10px 14px' }}>
          <Eyebrow>legend</Eyebrow>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 10, height: 10, borderRadius: 999, background: 'var(--gold)' }} /><span className="mono" style={{ fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--fg-mute)' }}>your location</span></div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 10, height: 10, background: 'var(--gold)', transform: 'rotate(45deg)' }} /><span className="mono" style={{ fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--fg-mute)' }}>introduction</span></div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 14, height: 0, borderTop: '1px dashed rgba(255,255,255,0.4)' }} /><span className="mono" style={{ fontSize: 10, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--fg-mute)' }}>supply link</span></div>
          </div>
        </div>
      </div>

      {/* right panel */}
      <div style={{ background: 'var(--ink-800)', borderLeft: '1px solid var(--line-10)', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: 20, borderBottom: '1px solid var(--line-10)' }}>
          <Eyebrow>filters</Eyebrow>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 10 }}>
            {['Launch 6 only','Visit-due','Show intros','Show supply links'].map(o => (
              <label key={o} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12 }}>
                <span style={{ width: 14, height: 14, border: '1px solid var(--line-30)', background: o === 'Launch 6 only' ? 'var(--gold)' : 'transparent' }} />
                {o}
              </label>
            ))}
          </div>
        </div>
        <div style={{ padding: 20, flex: 1 }}>
          <Eyebrow gold>selected · ndlovu steel works</Eyebrow>
          <div className="placeholder-photo" style={{ height: 120, marginTop: 10 }}>photo</div>
          <div style={{ fontSize: 18, fontWeight: 500, marginTop: 10 }}>Ndlovu Steel Works</div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 4 }}>manufacturing · donnington · 2.4 km</div>
          <div style={{ display: 'flex', gap: 6, marginTop: 10 }}><Pill tone="gold">intro made</Pill><Pill tone="solid">launch 6</Pill></div>
          <div style={{ marginTop: 14, fontSize: 13, color: 'var(--fg-mute)', lineHeight: 1.6 }}>
            Family-run forge, 28 years. Owner Lucas Ndlovu. Last visit 6d ago — kept warm. Intro to Roy pending Friday.
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginTop: 14 }}>
            <Button variant="primary" size="sm" icon={I.mic}>Log visit</Button>
            <Button variant="ghost" size="sm">Open detail</Button>
          </div>
        </div>
      </div>
    </div>
  );
}

window.MapMobile = MapMobile;
window.MapMobilePinDrop = MapMobilePinDrop;
window.MapDesktop = MapDesktop;
