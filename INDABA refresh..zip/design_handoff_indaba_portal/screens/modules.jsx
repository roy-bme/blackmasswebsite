/* INTROS · EVENTS · FEED · COMPLIANCE · AGENT · SETTINGS */

/* ---------- INTROS ---------- */
function IntrosMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <PhoneHeader title="intros" eyebrow="indaba · bd · tafadzwa" greeting="12 open · 3 awaiting roy" />
        <div style={{ padding: '10px 16px', borderBottom: '1px solid var(--line-10)', display: 'flex', gap: 6, overflowX: 'auto' }} className="thin-scroll">
          <Pill tone="gold">All · 12</Pill>
          <Pill>Pending</Pill>
          <Pill>Approved</Pill>
          <Pill>Warm</Pill>
          <Pill>Cold</Pill>
        </div>
        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 16px 100px' }}>
          {[
            { n: 'Tendai Moyo', r: 'GM, Matabele Mining', w: 'warm', s: 'pending', pain: 'cross-border invoicing fees', via: 'BCCI · Memory' },
            { n: 'Sipho Khumalo', r: 'Owner, Imbizo Fuel', w: 'cold', s: 'approved', pain: 'fx settlement delays', via: 'cold outreach' },
            { n: 'Memory Dube', r: 'BCCI Director', w: 'warm', s: 'pending', pain: 'merchant access to USD rails', via: 'introduced by roy' },
          ].map((it) => (
            <Card key={it.n} padding={14} style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 500 }}>{it.n}</div>
                  <div style={{ fontSize: 12, color: 'var(--fg-mute)', marginTop: 2 }}>{it.r}</div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'flex-end' }}>
                  <Pill tone={it.w === 'warm' ? 'gold' : 'neutral'}>{it.w}</Pill>
                  <Pill tone={it.s === 'approved' ? 'ok' : 'warn'}>{it.s}</Pill>
                </div>
              </div>
              <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--line-10)' }}>
                <Eyebrow>pain point</Eyebrow>
                <div style={{ fontSize: 13, color: 'var(--fg-mute)', marginTop: 4 }}>{it.pain}</div>
                <div className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 8 }}>via · {it.via}</div>
              </div>
            </Card>
          ))}
        </div>
        <PhoneTabs active="Intros" tabs={[
          { label: 'This wk', icon: I.home }, { label: 'Intros', icon: I.intros, badge: '3' },
          { label: 'Events', icon: I.events }, { label: 'Directory', icon: I.list }, { label: 'Feed', icon: I.feed },
        ]} />
      </div>
    </Phone>
  );
}

function IntrosDesktop() {
  return (
    <div className="indaba" style={{ width: 1440, height: 900, display: 'grid', gridTemplateColumns: '224px 1fr' }}>
      <DesktopRail role="admin" active="Intros" />
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <DesktopHeader role="admin" name="Roy" crumbs={['Indaba','Intros']} />
        <div style={{ padding: '16px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--line-10)' }}>
          <div>
            <Eyebrow>introductions · awaiting your approval · 3</Eyebrow>
            <h1 style={{ fontSize: 28, fontWeight: 300, margin: '4px 0 0', letterSpacing: '-0.02em' }}>intros pipeline</h1>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <Pill tone="gold">All · 12</Pill><Pill>Pending · 5</Pill><Pill>Approved · 7</Pill>
            <Button variant="primary" size="sm" icon={I.plus}>New intro</Button>
          </div>
        </div>
        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 460px', overflow: 'hidden' }}>
          <div className="thin-scroll" style={{ overflowY: 'auto', padding: 24 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {[
                { n: 'Tendai Moyo', r: 'GM, Matabele Mining', biz: 'Matabele Mining', w: 'warm', s: 'pending', selected: true },
                { n: 'Sipho Khumalo', r: 'Owner, Imbizo Fuel', biz: 'Imbizo Fuel', w: 'cold', s: 'approved' },
                { n: 'Memory Dube', r: 'BCCI Director', biz: '—', w: 'warm', s: 'pending' },
                { n: 'Lucas Ndlovu', r: 'Owner, Ndlovu Steel', biz: 'Ndlovu Steel', w: 'warm', s: 'approved' },
                { n: 'Patience Sibanda', r: 'CFO, Khami Logistics', biz: 'Khami Logistics', w: 'warm', s: 'approved' },
                { n: 'Tonderai M.', r: 'Buyer, BYO Hardware', biz: 'BYO Hardware', w: 'cold', s: 'pending' },
              ].map((it) => (
                <div key={it.n} style={{
                  background: 'var(--ink-800)',
                  border: `1px solid ${it.selected ? 'var(--gold)' : 'var(--line-10)'}`,
                  padding: 16, cursor: 'pointer',
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 500 }}>{it.n}</div>
                      <div style={{ fontSize: 12, color: 'var(--fg-mute)', marginTop: 2 }}>{it.r}</div>
                    </div>
                    <Pill tone={it.s === 'approved' ? 'ok' : 'warn'}>{it.s}</Pill>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 14, paddingTop: 10, borderTop: '1px solid var(--line-10)' }}>
                    <span className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>biz · {it.biz}</span>
                    <Pill tone={it.w === 'warm' ? 'gold' : 'neutral'}>{it.w}</Pill>
                  </div>
                </div>
              ))}
            </div>
          </div>
          {/* detail */}
          <div style={{ borderLeft: '1px solid var(--line-10)', background: 'var(--ink-800)', padding: 24, overflowY: 'auto' }}>
            <Eyebrow gold>selected · pending approval</Eyebrow>
            <h2 style={{ fontSize: 26, fontWeight: 400, margin: '8px 0 4px', letterSpacing: '-0.01em' }}>Tendai Moyo</h2>
            <div style={{ fontSize: 13, color: 'var(--fg-mute)' }}>GM, Matabele Mining · Bulawayo</div>
            <div style={{ display: 'flex', gap: 6, marginTop: 12 }}><Pill tone="gold">warm</Pill><Pill>via memory · bcci</Pill></div>

            <div style={{ marginTop: 20 }}>
              <Eyebrow style={{ marginBottom: 6 }}>pain points</Eyebrow>
              <div style={{ fontSize: 13, color: 'var(--fg-mute)', lineHeight: 1.6 }}>
                Cross-border invoicing fees with SA suppliers eating ~3.4% per cycle. FX volatility hits steel input costs. Wants USD-stable settlement rail.
              </div>
            </div>
            <div style={{ marginTop: 20 }}>
              <Eyebrow style={{ marginBottom: 6 }}>recommended action</Eyebrow>
              <div style={{ fontSize: 13, color: 'var(--fg-mute)', lineHeight: 1.6 }}>
                Bring to BCCI luncheon Wed. Soft pitch on cross-border rail. Don't lead with technical product.
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 24, paddingTop: 18, borderTop: '1px solid var(--line-10)' }}>
              <Button variant="primary" size="md">Approve (Roy)</Button>
              <Button variant="ghost" size="md">Add notes</Button>
              <Button variant="bare" size="md" style={{ marginLeft: 'auto', color: 'var(--bad)' }}>Decline</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- EVENTS ---------- */
function EventsMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <PhoneHeader title="events" eyebrow="indaba · bd · tafadzwa" greeting="5 upcoming · 12 past · 30d" />
        <div style={{ padding: '10px 16px', borderBottom: '1px solid var(--line-10)', display: 'flex', gap: 6 }}>
          <Pill tone="gold">Upcoming · 5</Pill>
          <Pill>Past · 12</Pill>
          <Button variant="ghost" size="sm" style={{ marginLeft: 'auto' }} icon={I.plus}>Log</Button>
        </div>
        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 16px 100px' }}>
          {[
            { t: 'BCCI Quarterly Luncheon', d: 'Wed · 29 apr · 12:30', v: 'Rainbow Hotel', urgent: true, p: 'high' },
            { t: 'Mining Indaba Africa Mixer', d: 'Fri · 1 may · 18:00', v: 'Holiday Inn', p: 'high' },
            { t: 'BYO Chamber AGM', d: 'Tue · 5 may · 09:00', v: 'NUST campus', p: 'med' },
            { t: 'Cross-border Trade Forum', d: 'Wed · 13 may · 14:00', v: 'Bulawayo Club', p: 'low' },
          ].map((e) => (
            <Card key={e.t} padding={0} style={{ marginBottom: 8, display: 'flex' }}>
              <div style={{ width: 4, background: e.p === 'high' ? 'var(--gold)' : e.p === 'med' ? 'rgba(255,255,255,0.4)' : 'var(--line-15)' }} />
              <div style={{ flex: 1, padding: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 500 }}>{e.t}</div>
                    <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 6 }}>{e.d}</div>
                    <div style={{ fontSize: 12, color: 'var(--fg-dim)', marginTop: 4 }}>{e.v}</div>
                  </div>
                  {e.urgent ? <Pill tone="gold">2d</Pill> : null}
                </div>
              </div>
            </Card>
          ))}
        </div>
        <PhoneTabs active="Events" tabs={[
          { label: 'This wk', icon: I.home }, { label: 'Intros', icon: I.intros },
          { label: 'Events', icon: I.events, badge: '5' }, { label: 'Directory', icon: I.list }, { label: 'Feed', icon: I.feed },
        ]} />
      </div>
    </Phone>
  );
}

/* ---------- FEED ---------- */
function FeedMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <PhoneHeader title="feed" eyebrow="indaba · ground_ops · brendon" greeting="4 unread · today" />
        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 16px 140px' }}>
          <Eyebrow>today · mon 27 apr</Eyebrow>
          {[
            { who: 'Roy', when: '06:14', gold: true, body: 'focus the week on belmont. matabele mining is the priority — chase a meeting before friday.', replies: 2 },
            { who: 'Tafadzwa', when: '08:02', body: 'BCCI confirmed 12 attendees for Wed. Bringing Tendai Moyo as +1.' },
            { who: 'Agent', when: '06:12', body: 'Daily brief generated. 3 candidates discovered overnight.', mono: true },
            { who: 'Brendon', when: 'yesterday', img: true, body: 'Visited Ndlovu Steel — kept it warm. Owner travelling, returns Friday.' },
          ].map((p,i) => (
            <Card key={i} padding={14} style={{ marginBottom: 8 }}>
              <div style={{ display: 'flex', gap: 10 }}>
                <Avatar name={p.who} size={32} gold={p.gold} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{p.who}</span>
                    <span className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.08em' }}>{p.when}</span>
                  </div>
                  <div style={{ fontSize: p.mono ? 12 : 13, color: 'var(--fg)', marginTop: 6, lineHeight: 1.5, fontFamily: p.mono ? 'var(--mono)' : 'var(--sans)' }}>{p.body}</div>
                  {p.img ? <div className="placeholder-photo" style={{ height: 90, marginTop: 10 }}>visit photo</div> : null}
                  {p.replies ? <div className="mono" style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 8 }}>{p.replies} replies →</div> : null}
                </div>
              </div>
            </Card>
          ))}
        </div>
        {/* Composer */}
        <div style={{ position: 'absolute', bottom: 64, left: 0, right: 0, padding: '10px 14px', background: 'rgba(20,22,26,0.95)', borderTop: '1px solid var(--line-15)', display: 'flex', gap: 8, alignItems: 'center' }}>
          <Pill tone="gold">ground_ops</Pill>
          <div style={{ flex: 1, background: 'var(--ink-700)', border: '1px solid var(--line-15)', padding: '10px 12px', fontSize: 13, color: 'var(--fg-dim)' }}>Reply to roy…</div>
          <span style={{ color: 'var(--fg-dim)' }}>{I.camera}</span>
          <span style={{ color: 'var(--gold)' }}>{I.arrow}</span>
        </div>
        <PhoneTabs active="Feed" tabs={[
          { label: 'Today', icon: I.home }, { label: 'Map', icon: I.map },
          { label: 'Directory', icon: I.list }, { label: 'Feed', icon: I.feed, badge: '4' },
        ]} />
      </div>
    </Phone>
  );
}

/* ---------- COMPLIANCE QUEUE ---------- */
function ComplianceMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <PhoneHeader title="compliance" eyebrow="indaba · queue · victor" greeting="7 open · 1 blocker" />
        <div style={{ padding: '10px 16px', borderBottom: '1px solid var(--line-10)', display: 'flex', gap: 6 }}>
          <Pill tone="gold">Open · 7</Pill><Pill>In review · 2</Pill><Pill>Resolved</Pill>
        </div>
        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: '12px 16px 90px' }}>
          {[
            { sev: 'blocker', t: 'KYB · missing source-of-funds', sub: 'Matabele Mining', src: 'agent', when: '12m' },
            { sev: 'warning', t: 'Cross-border supply link · ZA', sub: 'Khami Logistics → SA Foods', src: 'rule', when: '38m' },
            { sev: 'warning', t: 'License expiry in 30d', sub: 'Imbizo Fuel', src: 'rule', when: '2h' },
            { sev: 'info', t: 'Reg signal · RBZ circular 03/26', sub: '3 merchants exposed', src: 'agent', when: '5h' },
          ].map((it) => (
            <Card key={it.t} padding={14} style={{ marginBottom: 8, borderLeft: `2px solid ${it.sev==='blocker'?'var(--bad)':it.sev==='warning'?'var(--warn)':'var(--info)'}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <Pill tone={it.sev==='blocker'?'bad':it.sev==='warning'?'warn':'info'}>{it.sev}</Pill>
                  <div style={{ fontSize: 14, fontWeight: 500, marginTop: 8 }}>{it.t}</div>
                  <div style={{ fontSize: 12, color: 'var(--fg-mute)', marginTop: 4 }}>{it.sub}</div>
                </div>
                <span className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)' }}>{it.when}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, paddingTop: 10, borderTop: '1px solid var(--line-10)' }}>
                <span className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>src · {it.src}</span>
                <Button variant="ghost" size="sm">Review</Button>
              </div>
            </Card>
          ))}
        </div>
        <PhoneTabs active="Queue" tabs={[
          { label: 'Today', icon: I.home }, { label: 'Queue', icon: I.shield, badge: '7' },
          { label: 'Agent', icon: I.agent }, { label: 'Feed', icon: I.feed },
        ]} />
      </div>
    </Phone>
  );
}

/* ---------- AGENT CONSOLE ---------- */
function AgentConsoleDesktop() {
  return (
    <div className="indaba" style={{ width: 1440, height: 900, display: 'grid', gridTemplateColumns: '224px 1fr' }}>
      <DesktopRail role="admin" active="Agent" />
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <DesktopHeader role="admin" name="Roy" crumbs={['Indaba','Agent','Console']} />
        <div style={{ flex: 1, padding: 24, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, overflow: 'hidden' }}>
          {/* Left: brief + suggestions */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, overflow: 'hidden' }}>
            <Card padding={24} accent="var(--gold)">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Eyebrow gold>today's brief · 06:12 · indaba.intel</Eyebrow>
                <span className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)' }}>v.0.7.2 · 38s · ✓</span>
              </div>
              <h2 style={{ fontSize: 24, fontWeight: 400, letterSpacing: '-0.01em', margin: '12px 0 12px', lineHeight: 1.25 }}>
                Pilot is on track for week 17 launch. Three signals need a human.
              </h2>
              <div style={{ fontSize: 13, color: 'var(--fg-mute)', lineHeight: 1.7 }}>
                <p style={{ margin: '0 0 10px' }}>Mhlanga Mills LOI signed Friday — onboarding can begin Tuesday after Victor clears refreshed KYB. Ndlovu Steel intro is warm; Tafadzwa should bring Tendai Moyo to BCCI Wednesday.</p>
                <p style={{ margin: '0 0 10px' }}><strong style={{ color: 'var(--gold)' }}>Watch:</strong> RBZ circular 03/26 introduces a revised SI on cross-border merchant remittances. Three pilot merchants are exposed. Refresh KYB on Khami Logistics, Mhlanga Mills, BYO Hardware before Friday.</p>
                <p style={{ margin: 0 }}><strong style={{ color: 'var(--gold)' }}>Discovered:</strong> Hwange Coal Traders (92% match), Zambezi Cotton Co. (78%), Bulawayo Brake Pads (64%). Promote any from Suggested in Directory.</p>
              </div>
            </Card>
            <Card padding={20} style={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <Eyebrow style={{ marginBottom: 12 }}>suggested actions · 4</Eyebrow>
              <div className="thin-scroll" style={{ overflowY: 'auto' }}>
                {[
                  ['Promote Hwange Coal Traders to Identified','92% confidence · matches mining target profile','primary'],
                  ['Refresh KYB · Khami Logistics','RBZ 03/26 exposure · Friday deadline','warn'],
                  ['Schedule call · Tendai Moyo','warm intro · 6d since first contact','info'],
                  ['Mark target loop · Steel-Hardware','$18.4k/mo throughput · 4 nodes','gold'],
                ].map(([t,sub,tone],i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderTop: '1px solid var(--line-10)' }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{t}</div>
                      <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.08em', marginTop: 4 }}>{sub}</div>
                    </div>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <Button variant="primary" size="sm">Accept</Button>
                      <Button variant="bare" size="sm">Skip</Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
          {/* Right: runs + discovery */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, overflow: 'hidden' }}>
            <Card padding={20}>
              <Eyebrow style={{ marginBottom: 12 }}>recent runs · last 24h</Eyebrow>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--fg-mute)', lineHeight: 1.95 }}>
                {[
                  ['06:12','daily_brief','✓','38s','3 signals'],
                  ['04:48','discovery.bulawayo','✓','2m 14s','3 candidates'],
                  ['02:15','reg.scan.zw','!','11s','1 flag'],
                  ['23:40','supplychain.rescan','✓','1m 02s','+2 links'],
                  ['22:08','sector.watch.mining','✓','22s','—'],
                  ['20:00','agent.health','✓','3s','ok'],
                ].map(([t,name,st,dur,out]) => (
                  <div key={t+name} style={{ display: 'grid', gridTemplateColumns: '46px 1fr 22px 64px 1fr', gap: 8, padding: '4px 0', borderBottom: '1px solid var(--line-10)' }}>
                    <span style={{ color: 'var(--fg-dim)' }}>{t}</span>
                    <span style={{ color: '#fff' }}>{name}</span>
                    <span style={{ color: st==='✓' ? 'var(--ok)' : 'var(--warn)' }}>{st}</span>
                    <span>{dur}</span>
                    <span style={{ color: 'var(--fg-dim)' }}>{out}</span>
                  </div>
                ))}
              </div>
            </Card>
            <Card padding={20} style={{ flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <Eyebrow style={{ marginBottom: 12 }}>discovery feed · newest first</Eyebrow>
              <div className="thin-scroll" style={{ overflowY: 'auto' }}>
                {[
                  ['Hwange Coal Traders','candidate · mining · 92%','06:11'],
                  ['Zambezi Cotton Co.','candidate · agriculture · 78%','06:10'],
                  ['RBZ circular 03/26','regulatory signal · ZW · high','02:14'],
                  ['New supply link · Donnington → BYO','supply chain · medium','23:39'],
                  ['Bulawayo Brake Pads','candidate · manufacturing · 64%','22:51'],
                ].map(([t,sub,when],i) => (
                  <div key={i} style={{ padding: '10px 0', borderTop: '1px solid var(--line-10)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{t}</div>
                      <span className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)' }}>{when}</span>
                    </div>
                    <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 4 }}>{sub}</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- SETTINGS ---------- */
function SettingsMobile() {
  return (
    <Phone>
      <div className="indaba" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <PhoneHeader title="settings" eyebrow="indaba · profile" greeting="brendon · ops · bulawayo" />
        <div className="thin-scroll" style={{ flex: 1, overflowY: 'auto', padding: '20px 16px 90px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 24 }}>
            <Avatar name="Brendon" size={56} />
            <div>
              <div style={{ fontSize: 18, fontWeight: 500 }}>Brendon Mhlanga</div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 4 }}>ops · bulawayo · #b042</div>
            </div>
          </div>
          {[
            ['Name','Brendon Mhlanga'],
            ['Email','brendon@zimx.io'],
            ['Role','ops'],
            ['Password','••••••••••••'],
          ].map(([k,v]) => (
            <div key={k} style={{ padding: '14px 0', borderTop: '1px solid var(--line-10)' }}>
              <div className="mono" style={{ fontSize: 10, color: 'var(--fg-dim)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>{k}</div>
              <div style={{ fontSize: 14, marginTop: 4 }}>{v}</div>
            </div>
          ))}
          <div style={{ marginTop: 24 }}>
            <Button variant="danger" fullWidth>Sign out</Button>
          </div>
        </div>
      </div>
    </Phone>
  );
}

/* ---------- STATES catalog (loading / error / offline) ---------- */
function StatesCatalog() {
  return (
    <div className="indaba" style={{ width: 1280, padding: 32, background: 'var(--ink-700)' }}>
      <Eyebrow gold>cross-cutting · loading / error / empty / offline</Eyebrow>
      <h2 style={{ fontSize: 28, fontWeight: 300, letterSpacing: '-0.02em', margin: '8px 0 24px' }}>states catalog</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        {/* Skeleton list */}
        <Card padding={16}>
          <Eyebrow style={{ marginBottom: 10 }}>directory · loading skeleton</Eyebrow>
          {[0,1,2,3].map((i) => (
            <div key={i} style={{ borderTop: '1px solid var(--line-10)', padding: '12px 0' }}>
              <div className="skeleton" style={{ height: 12, width: '60%', marginBottom: 8 }} />
              <div className="skeleton" style={{ height: 9, width: '40%' }} />
            </div>
          ))}
        </Card>
        {/* Map loading */}
        <Card padding={0} style={{ overflow: 'hidden' }}>
          <div className="map-placeholder" style={{ height: 220, position: 'relative', opacity: 0.6 }}>
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span className="mono" style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.14em', textTransform: 'uppercase' }}>loading territory…</span>
            </div>
          </div>
        </Card>
        {/* Error */}
        <Card padding={16} style={{ border: '1px solid rgba(226,97,75,0.30)', background: 'rgba(226,97,75,0.04)' }}>
          <div style={{ color: 'var(--bad)', display: 'inline-flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
            {I.alert}<span className="mono" style={{ fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase' }}>error · 502</span>
          </div>
          <div style={{ fontSize: 14 }}>Couldn't load the directory.</div>
          <div style={{ fontSize: 12, color: 'var(--fg-mute)', marginTop: 4, marginBottom: 12 }}>Connection dropped. Try again.</div>
          <Button variant="ghost" size="sm" icon={I.refresh}>Retry</Button>
        </Card>
        {/* Empty */}
        <Card padding={16} style={{ border: '1px dashed var(--line-15)' }}>
          <Eyebrow style={{ marginBottom: 10 }}>compliance queue · empty</Eyebrow>
          <div style={{ fontSize: 14 }}>Queue is clear.</div>
          <div style={{ fontSize: 12, color: 'var(--fg-mute)', marginTop: 4 }}>The agent will surface items here as it finds them.</div>
        </Card>
        {/* Offline banner */}
        <Card padding={14} style={{ gridColumn: 'span 2', border: '1px solid var(--warn)', background: 'rgba(230,168,60,0.06)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ color: 'var(--warn)' }}>{I.signal}</span>
            <div>
              <Eyebrow style={{ color: 'var(--warn)' }}>offline · brendon · 14:22</Eyebrow>
              <div style={{ fontSize: 13, marginTop: 2 }}>Showing cached map. 2 visit logs queued — will sync on reconnect.</div>
            </div>
            <span className="mono" style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>2 queued</span>
          </div>
        </Card>
        {/* Toast */}
        <Card padding={14} style={{ gridColumn: 'span 2', background: 'var(--ink-600)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ color: 'var(--ok)' }}>{I.check}</span>
          <div style={{ fontSize: 13 }}>Visit logged · Ndlovu Steel · 30s voice + photo</div>
          <span className="mono" style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--gold)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>undo</span>
        </Card>
      </div>
    </div>
  );
}

Object.assign(window, { IntrosMobile, IntrosDesktop, EventsMobile, FeedMobile, ComplianceMobile, AgentConsoleDesktop, SettingsMobile, StatesCatalog });
